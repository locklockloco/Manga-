@echo off
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (
  .venv\Scripts\python.exe start.py
) else (
  py start.py
)
if errorlevel 1 pause
