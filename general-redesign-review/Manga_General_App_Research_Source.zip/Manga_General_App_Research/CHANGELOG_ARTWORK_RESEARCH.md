# Unreleased artwork-boundary changes

This is a working-tree experiment, not a numbered release. The published integrated package and GitHub branch are unchanged. Existing workspaces and manual corrections are not automatically migrated.

- Add independent artwork, dialogue, standalone text/SFX and uncertainty analysis before final rectangular extraction. The original composition graph remains the scene-range finder; its combined artwork/dialogue envelope no longer sets the final crop.
- Detect optional dialogue with paper geometry, glyph evidence and optional local OCR. Exclude confirmed dialogue from drawing bounds while retaining substantial painted components across the whole composition. No person/face detector chooses the crop.
- Protect flat painted sky/walls, neutral drawing details and unresolved marks; flag unsupported frame/fringe inferences. Preserve original scene anchors for reading order even when optional text above a scene is clipped.
- Handle thin-outline paper leaks, JPEG outline halos, centered punctuation and some attached exterior lettering. Preserve uncertain source locations for inspection. Internal dialogue overlap is explicitly recorded as a rectangular geometry limitation.
- Keep native pixels, natural proportions, source maps, immutable history, output checksum repair and job-identity checks. Mark saved layer evidence stale after manual geometry changes.
- Add exact-pixel, engine/settings-keyed atomic OCR transcription caching. Cached OCR never reuses old crop rectangles or artwork masks.
- Fix review-worker state snapshots and zombie-process detection so completed/paused/interrupted jobs remain resumable and accurately presented. Route uncertain boundary inferences to the cutoff review queue.
- Add original-source comparison tooling and regression tests for frozen real Chapter 1 examples, multi-character scenes, weapons, monochrome art, stale corrections, cache corruption and worker-state races.

Validation: forty fixed Chapter 1 comparisons, the eight originally reported examples, and a fresh 194-strip final detector run. All forty actual final pairs were inspected; whole-chapter thumbnail inspection is not a native-resolution semantic audit. Final repository checks: 200 passed, 11 skipped external fixtures, four large stress cases deselected. No crop is VERIFIED.

Remaining failures include SFX-driven margins (old P084/P112/P224), P126's gray bottom margin, compound scenes (P091/P214), internal space between staggered frames (P274) and internal balloon overlap (P267). Selected exterior-dialogue framing improved; the general visual acceptance criterion is not met. See `/workspace/artwork-boundary-research/RESEARCH_REPORT.md` for actual comparisons, source maps, timings and measured limits. Native Windows/macOS startup and fresh 200/500-strip stress runs were not evaluated in this experiment.
