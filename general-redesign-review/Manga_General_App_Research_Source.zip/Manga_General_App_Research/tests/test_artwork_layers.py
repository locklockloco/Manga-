"""Layer geometry safety checks; real-case visual correctness is measured separately."""
import json,os
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
import pytest
from manga_tool import artwork_layers as layers


def scene():
    im=Image.new('RGB',(600,650),'white');d=ImageDraw.Draw(im)
    d.rectangle((15,170,584,630),fill='#466372')
    d.ellipse((80,210,220,390),fill='#d3ac81');d.rectangle((75,370,230,620),fill='#346b98')
    d.ellipse((370,200,500,370),fill='#aa846a');d.rectangle((360,360,530,620),fill='#803d40')
    # A real weapon extends outside both character boxes.
    d.line((230,470,570,190),fill='#151b21',width=9)
    d.ellipse((30,8,310,235),fill='white',outline='black',width=3)
    return np.array(im)


def test_artwork_geometry_does_not_union_optional_balloon(monkeypatch):
    rgb=scene()
    monkeypatch.setattr(layers,'ocr_words',lambda _:([{'text':'IMPORTANT','confidence':95,'box':[80,60,235,95]},{'text':'DIALOGUE','confidence':96,'box':[80,110,235,145]}],'mocked'))
    bounds,evidence,mask=layers.analyze(rgb)
    assert bounds[1]>130
    assert bounds[0]<=15 and bounds[2]>=585 and bounds[3]>=631
    assert len(evidence['balloons'])==1
    assert evidence['dialogue_pixels_removed']>0
    assert evidence['rectangular_geometry_limitation']
    assert mask.dtype==np.uint8
    assert np.array_equal(rgb,scene())


def test_multiple_characters_and_weapon_remain_in_one_composition(monkeypatch):
    monkeypatch.setattr(layers,'ocr_words',lambda _:([],'unavailable'))
    bound,evidence,_=layers.analyze(scene())
    assert bound[0]<=15 and bound[2]>=585 and bound[3]>=631
    assert evidence['human_verified'] is False


def test_ambiguous_monochrome_ink_is_not_dialogue_without_evidence(monkeypatch):
    monkeypatch.setattr(layers,'ocr_words',lambda _:([],'unavailable'))
    im=Image.new('RGB',(400,500),'white');d=ImageDraw.Draw(im)
    d.ellipse((30,30,370,470),outline='black',width=7)
    for y in [100,160,220]:d.line((70,y,330,y+100),fill='black',width=5)
    b,e,m=layers.analyze(np.array(im))
    assert not e['balloons']
    assert b[0]<=30 and b[1]<=30 and b[2]>=371 and b[3]>=471


def test_dialogue_layers_are_analysis_only_and_source_maps_are_traceable(monkeypatch):
    from manga_tool.artwork_layers import refine_proposals
    class Chapter:
        def preview(self,bounds,max_size):return Image.fromarray(scene())
        def regions(self,bounds):return [{'source_id':'original','chapter_bounds':bounds}]
    p={'bounds':[0,0,600,650]}
    monkeypatch.setattr(layers,'ocr_words',lambda _:([{'text':'IMPORTANT','confidence':95,'box':[80,60,235,95]},{'text':'DIALOGUE','confidence':96,'box':[80,110,235,145]}],'mocked'))
    refined=refine_proposals(Chapter(),[p])[0]
    assert refined['reading_order_bounds']==[0,0,600,650]
    assert refined['artwork_layers']['source_layers']['speech_dialogue']
    assert refined['artwork_layers']['source_layers']['illustrated_artwork']
    assert refined['bounds'][1]>130
    assert 'INTERNAL_DIALOGUE_RECTANGLE_LIMITATION' in refined['ambiguity_flags']


def test_metadata_tasks_remain_recoverable_without_creating_artwork():
    p={'bounds':[0,0,100,100],'metadata_only':True,'review_task':True}
    assert layers.refine_proposals(None,[p])[0] is p


@pytest.mark.skipif(not os.environ.get('MANGA_ARTWORK_RESEARCH'),reason='Requires actual source-backed 40-case experiment')
def test_real_frozen_eight_frames_and_source_identity():
    root=Path(os.environ['MANGA_ARTWORK_RESEARCH'])
    frames=json.loads((root/'frozen_reported_art_frames.json').read_text())['cases']
    results={p['baseline_id']:p for p in json.loads((root/'targeted_40_results.json').read_text())['cases']}
    for f in frames:
        p=results[f['baseline_id']];x,y,xx,yy=f['minimum_composition_rectangle'];a,b,c,d=p['relative_bounds']
        assert a<=x+2 and b<=y+2 and c>=xx-2 and d>=yy-2
        assert a>=x-12 and b>=y-12 and c<=xx+12 and d<=yy+12
        if f['rectangular_balloon_limitation']:
            assert p['evidence']['rectangular_geometry_limitation']
            assert p['source_analysis_envelope'][0]<p['baseline_bounds'][0]
    assert len(results)==40
    assert all(not p.get('human_approved',False) for p in results.values())


def test_monochrome_fallback_also_gets_separate_layer_analysis(monkeypatch):
    from manga_tool import detection,composition
    proposal={'bounds':[0,0,100,200]};calls=[]
    monkeypatch.setattr(composition,'discover',lambda *a,**k:([],{}))
    monkeypatch.setattr(detection,'legacy_propose',lambda *a:([proposal],['stats'],['gutter']))
    monkeypatch.setattr(detection,'Chapter',lambda *a:None)
    def refine(chapter,proposals,*args):
        calls.extend(proposals);return proposals
    monkeypatch.setattr(layers,'refine_proposals',refine)
    result=detection.propose_compositions('unused',[])
    assert calls==[proposal]
    assert result==([proposal],['stats'],['gutter'])


def test_manual_geometry_marks_previous_layer_source_maps_stale(tmp_path):
    from manga_tool.pipeline import export_panel,digest
    image=tmp_path/'source.png';Image.fromarray(scene()[:100,:100]).save(image)
    original_hash=digest(image)
    sources=[{'id':'S1','order':1,'width':100,'height':100,'y0':0,'y1':100,'path':'source.png','sha256':original_hash}]
    manifest={'sources':sources,'joins':[]}
    panel={'id':'TEST_P001','status':'NEEDS_REVIEW','bounds':[10,10,90,90],'revision':1,'classification':'illustration','artwork_layers':{'native_bounds':[0,0,100,100],'source_layers':{'illustrated_artwork':[{'bounds':[0,0,100,100]}]}}}
    export_panel(tmp_path,manifest,panel)
    assert panel['artwork_layers']['stale_after_geometry_change']
    assert not panel['artwork_layers']['applies_to_current_geometry']
    assert panel['artwork_layers']['source_layers']['illustrated_artwork'][0]['bounds']==[0,0,100,100]
    assert digest(image)==original_hash


@pytest.mark.skipif(not os.environ.get('MANGA_ARTWORK_RESEARCH'),reason='Requires actual original cross-strip portrait envelope')
def test_portrait_original_envelope_does_not_expand_to_balloon_tips():
    root=Path(os.environ['MANGA_ARTWORK_RESEARCH'])
    with Image.open(root/'portrait_raw_original.png') as image:
        rgb=np.asarray(image.convert('RGB'))
    # These are source-context coordinates, not the previous trimmed crop.
    assert rgb.shape[:2]==(736,494)
    bound,evidence,mask=layers.analyze(rgb)
    assert bound[0]>=76 and bound[2]<=494 and bound[2]-bound[0]<420
    assert bound[0]<=88 and bound[1]<=65 and bound[2]>=481 and bound[3]>=724
    assert evidence['rectangular_geometry_limitation']
    assert evidence['dialogue_pixels']>0
    assert not evidence['human_verified']


def test_ocr_cache_checks_pixels_contents_and_atomic_recovery(tmp_path,monkeypatch):
    calls=[]
    def read(rgb):
        calls.append(1);return [{'text':'DIALOGUE','confidence':95.0,'box':[2,2,16,9]}],'available'
    monkeypatch.setattr(layers,'ocr_words',read)
    image=np.full((25,30,3),255,np.uint8)
    a,status=layers.cached_ocr_words(image,tmp_path);assert len(calls)==1
    assert layers.cached_ocr_words(image,tmp_path)[0]==a and len(calls)==1
    changed=image.copy();changed[12,12]=0
    layers.cached_ocr_words(changed,tmp_path);assert len(calls)==2
    cache=tmp_path/(layers.ocr_fingerprint(image)+'.json')
    cache.write_text('{truncated')
    layers.cached_ocr_words(image,tmp_path);assert len(calls)==3
    old=cache.read_bytes()
    def fail(*args):raise OSError('interrupted atomic cache write')
    with monkeypatch.context() as patch:
        patch.setattr(layers.os,'replace',fail)
        with pytest.raises(OSError):layers.write_ocr_cache(image,tmp_path,a)
    assert cache.read_bytes()==old
    assert not list(tmp_path.glob('*.tmp'))


@pytest.mark.skipif(not os.environ.get('MANGA_ARTWORK_RESEARCH'),reason='Requires original-source additional full-run regression case')
def test_extra_full_run_portrait_has_no_dialogue_header_expansion():
    root=Path(os.environ['MANGA_ARTWORK_RESEARCH'])
    m=json.loads((root/'full_r2_output/reports/manifest.json').read_text())
    from manga_tool.chapter import Chapter
    p=next(p for p in m['panels'] if p['id']=='CH01_P302')
    with Chapter(root/'full_r2_output',m['sources']).render(p['artwork_layers']['original_envelope']) as im:
        b,e,_=layers.analyze(np.asarray(im.convert('RGB')))
    # Source column 450 is white through row 148; the printed frame starts
    # at row 149. The earlier component envelope at 131 included balloon ink.
    assert b[1]>=140 and b[1]<=149
    assert b[0]<=104 and b[2]>=501 and b[3]>=793
    assert e['dialogue_pixels']>0 and e['rectangular_geometry_limitation']


@pytest.mark.skipif(not os.environ.get('MANGA_ARTWORK_RESEARCH'),reason='Requires native Chapter 1 full-source regression fixtures')
@pytest.mark.parametrize('original_envelope,minimum,maximum',[
    ([0,178296,690,179220],[0,170,690,913],[0,160,690,924]),
    ([56,223020,550,223848],[92,198,483,686],[80,186,494,698]),
    ([32,54876,470,55276],[9,81,427,390],[0,73,438,400]),
])
def test_exterior_outline_halos_and_punctuation_do_not_expand_frames(original_envelope,minimum,maximum):
    root=Path(os.environ['MANGA_ARTWORK_RESEARCH']);base=root/'full_r3_output'
    m=json.loads((base/'reports/manifest.json').read_text())
    from manga_tool.chapter import Chapter
    with Chapter(base,m['sources']).render(original_envelope) as image:
        b,e,_=layers.analyze(np.asarray(image.convert('RGB')),ocr_cache=base/'review/cache/artwork_ocr')
    assert b[0]<=minimum[0]+2 and b[1]<=minimum[1]+2 and b[2]>=minimum[2]-2 and b[3]>=minimum[3]-2
    assert b[0]>=maximum[0] and b[1]>=maximum[1] and b[2]<=maximum[2] and b[3]<=maximum[3]
    assert not e['human_verified']


def test_frame_inference_preserves_neutral_weapon_vents_outside_frame(monkeypatch):
    monkeypatch.setattr(layers,'ocr_words',lambda _:([],'unavailable'))
    im=Image.fromarray(scene());d=ImageDraw.Draw(im)
    d.rectangle((440,35,480,250),fill='#777777',outline='black',width=3)
    for y in [55,95,135,175]:d.rectangle((450,y,470,y+17),fill='white',outline='black',width=2)
    b,e,_=layers.analyze(np.asarray(im))
    assert b[1]<=35 and b[2]>=481
    assert not e['frame_text_evidence']


@pytest.mark.skipif(not os.environ.get('MANGA_ARTWORK_RESEARCH'),reason='Requires native Chapter 1 source-backed cases')
def test_outlined_sfx_header_does_not_expand_complete_scene():
    root=Path(os.environ['MANGA_ARTWORK_RESEARCH']);base=root/'full_r3_output'
    m=json.loads((base/'reports/manifest.json').read_text())
    from manga_tool.chapter import Chapter
    envelope=[36,50932,658,51640]
    with Chapter(base,m['sources']).render(envelope) as image:
        b,e,_=layers.analyze(np.asarray(image.convert('RGB')),ocr_cache=base/'review/cache/artwork_ocr')
    assert 202<=b[1]<=214 and b[0]<=12 and b[2]>=609 and b[3]>=695
    assert e['frame_text_evidence'] and not e['human_verified']


@pytest.mark.skipif(not os.environ.get('MANGA_ARTWORK_RESEARCH'),reason='Requires original-source thin-outline balloon regression')
def test_thin_balloon_outline_leak_does_not_merge_with_external_paper():
    root=Path(os.environ['MANGA_ARTWORK_RESEARCH']);base=root/'full_r5_output'
    m=json.loads((base/'reports/manifest.json').read_text())
    from manga_tool.chapter import Chapter
    envelope=[108,171444,554,172088]
    with Chapter(base,m['sources']).render(envelope) as image:
        b,e,_=layers.analyze(np.asarray(image.convert('RGB')),ocr_cache=base/'review/cache/artwork_ocr')
    assert 185<=b[1]<=198 and b[0]<=10 and b[2]>=436 and b[3]>=636
    assert e['balloons'] and e['dialogue_pixels_removed']>0
    assert not e['human_verified']
