"""Research contract tests use synthetic references, not manga accuracy gold."""
import copy
import json
from pathlib import Path

import pytest
from PIL import Image

from manga_tool.benchmark.dataset import chapter_from_workspace, freeze_dataset, load_dataset, source_regions
from manga_tool.benchmark.annotations import AnnotationStore
from manga_tool.benchmark.score import evaluate, retention
from manga_tool.benchmark.web import create_annotation_app


@pytest.fixture
def corpus(tmp_path):
    import hashlib
    work = tmp_path/'chapter'; (work/'reports').mkdir(parents=True)
    image = work/'source.png'; Image.new('RGB',(100,200),'white').save(image)
    sha = hashlib.sha256(image.read_bytes()).hexdigest()
    manifest = {'sources':[{'id':'S0001','order':1,'original_name':'source.png','path':'source.png','width':100,'height':200,'y0':0,'y1':200,'sha256':sha}]}
    (work/'reports/manifest.json').write_text(json.dumps(manifest))
    chapter = chapter_from_workspace(work,'TEST')
    path = tmp_path/'dataset.json'
    dataset = freeze_dataset(path,[chapter],[{'id':'W1','chapter_id':'TEST','bounds':[0,0,100,200]}],{'test_fixture':True})
    return path, dataset, chapter


def label(chapter, id='ART1', bounds=None, kind='artwork'):
    bounds = bounds or [0,0,100,100]
    return {'id':id,'chapter_id':chapter['chapter_id'],'kind':kind,'bounds':bounds,
            'ideal_crop_bounds':bounds,'layers':[],'must_keep_boxes':[],'verified':True,'verified_by':'Synthetic test reviewer',
            'reviewer_role':'human','review_checklist':dict.fromkeys(['native_source_inspected','neighbors_checked','complete_composition_checked','optional_text_checked'],True)}


def output(chapter,bounds,id='P1',status='exported'):
    return {'id':id,'bounds':bounds,'kind':'artwork','status':status,'source_regions':source_regions(chapter,bounds),'human_approved':False}


def score(dataset, chapter, annotations, outputs, exhaustive=False):
    gold={'dataset_sha256':dataset['dataset_sha256'],'chapters':[{'chapter_id':'TEST','annotations':annotations,
         'exhaustively_labeled':exhaustive,'exhaustive_review':{'reviewer_role':'human','reviewer':'Synthetic test reviewer'} if exhaustive else None}]}
    pred={'dataset_sha256':dataset['dataset_sha256'],'chapters':[{'chapter_id':'TEST','outputs':outputs}]}
    return evaluate(dataset,gold,pred)['chapters'][0]


def test_frozen_dataset_and_source_changes_are_detected(corpus):
    path,dataset,chapter=corpus
    assert load_dataset(path,True)['dataset_sha256']==dataset['dataset_sha256']
    value=json.loads(path.read_text());value['chapters'][0]['split']='holdout';path.write_text(json.dumps(value))
    with pytest.raises(ValueError,match='hash'):load_dataset(path)


def test_modified_native_source_blocks_reuse_and_label_commit(corpus):
    path,_,chapter=corpus;store=AnnotationStore(path)
    Image.new('RGB',(100,200),'black').save(chapter['source_files'][0]['path'])
    with pytest.raises(ValueError,match='fingerprint'):load_dataset(path,True)
    with pytest.raises(ValueError,match='source changed'):store.save(label(chapter))


def test_zero_reviewed_labels_cannot_produce_score_or_gold(corpus):
    path,dataset,chapter=corpus;store=AnnotationStore(path)
    a=label(chapter);a['verified']=False;store.save(a)
    result=evaluate(dataset,store.export(),{'dataset_sha256':dataset['dataset_sha256'],'chapters':[]})
    assert result['chapters'][0]['artwork_recall'] is None
    assert result['release_gate']['status']=='BLOCKED'
    with pytest.raises(ValueError,match='zero human'):store.freeze('v1',path.parent/'gold.json')


def test_named_explicit_human_checklist_is_required(corpus):
    path,_,chapter=corpus;store=AnnotationStore(path)
    a=label(chapter);a['reviewer_role']='assistant'
    with pytest.raises(ValueError,match='human'):store.save(a)
    a=label(chapter);a['review_checklist']['neighbors_checked']=False
    with pytest.raises(ValueError,match='checklist'):store.save(a)
    assert not store.all()


def test_annotation_revision_restore_and_frozen_recovery(corpus,tmp_path,monkeypatch):
    path,_,chapter=corpus;store=AnnotationStore(path)
    a=store.save(label(chapter));assert a['revision']==1
    with pytest.raises(ValueError,match='another window'):store.save(label(chapter),0)
    snapshot=store.freeze('pilot-v1',tmp_path/'gold.json')
    with pytest.raises(ValueError,match='already frozen'):store.freeze('pilot-v1',tmp_path/'other.json')
    a=store.restore(a['id'],1,a['revision']);assert a['revision']==2 and not a['verified']
    store.recover_freeze('pilot-v1',tmp_path/'recovered.json')
    assert json.loads((tmp_path/'recovered.json').read_text())==snapshot


def test_exhaustive_review_is_invalidated_by_any_edit(corpus):
    path,_,chapter=corpus;store=AnnotationStore(path)
    a=store.save(label(chapter));store.confirm_exhaustive('TEST','Synthetic test reviewer',True)
    assert store.export()['chapters'][0]['exhaustively_labeled']
    a['notes']='adjusted';store.save(a,a['revision'])
    assert not store.export()['chapters'][0]['exhaustively_labeled']


def test_merge_split_review_and_text_are_separate_errors(corpus):
    _,dataset,c=corpus
    labels=[label(c,'A1',[0,0,100,80]),label(c,'A2',[0,100,100,180])]
    merged=score(dataset,c,labels,[output(c,[0,0,100,180])])
    assert merged['artwork_recall']==0 and merged['merged_crop_ids']==['P1']
    split=score(dataset,c,[label(c)],[output(c,[0,0,100,50]),output(c,[0,50,100,100],'P2')])
    assert split['split_artwork_ids']==['ART1'] and split['artwork_recall']==0
    review=score(dataset,c,[label(c)],[output(c,[0,0,100,100],status='needs_review')])
    assert review['artwork_recall']==0 and review['review_routed_not_success']==['ART1']
    negative=score(dataset,c,[label(c,kind='standalone_sfx')],[output(c,[0,0,100,100])])
    assert negative['false_text_exports']==[{'negative_id':'ART1','crop_id':'P1'}]


def test_partial_labels_do_not_claim_whole_chapter_precision(corpus):
    _,dataset,c=corpus
    partial=score(dataset,c,[label(c)],[output(c,[0,0,100,100])])
    assert partial['artwork_recall']==1 and partial['artwork_precision'] is None
    full=score(dataset,c,[label(c)],[output(c,[0,0,100,100])],True)
    assert full['artwork_precision']==1 and full['recall_95pct_wilson'][0]<1


def test_masks_are_distinct_from_box_proxy_and_small_weapons_are_protected(corpus):
    _,dataset,c=corpus;a=label(c)
    a['layers']=[{'kind':'artwork','polygon':[[0,0],[99,0],[99,99],[0,99]]}]
    assert retention(a,[[0,0,100,100]])==(1.0,10000,'native_polygon_mask')
    assert retention(a,[[0,0,100,50],[0,50,100,100]])[0]==1
    a['must_keep_boxes']=[[99,0,100,100]]
    r=score(dataset,c,[a],[output(c,[0,0,99,100])])
    assert r['artwork_recall']==0 and r['possible_cuts']
    a['layers']=[]
    r=score(dataset,c,[a],[output(c,[0,0,100,100])])
    assert r['mask_retention_complete_outputs'] is None


def test_coordinate_source_swap_and_self_approval_are_rejected(corpus):
    _,dataset,c=corpus;p=output(c,[0,0,100,100]);p['source_regions'][0]['sha256']='wrong'
    with pytest.raises(ValueError,match='source map'):score(dataset,c,[label(c)],[p])
    p=output(c,[0,0,100,100]);p['human_approved']=True
    with pytest.raises(ValueError,match='approve themselves'):score(dataset,c,[label(c)],[p])


def test_annotation_api_native_image_and_draft_do_not_approve_app(corpus):
    path,_,c=corpus;client=create_annotation_app(path).test_client()
    assert client.get('/').status_code==200
    native=client.get('/api/source/TEST?x0=0&y0=0&x1=100&y1=200')
    assert native.status_code==200 and native.data.startswith(b'\x89PNG')
    a=label(c);a['verified']=False
    response=client.post('/api/annotations',json={'annotation':a,'expected_revision':0})
    assert response.status_code==200 and response.json['verified'] is False
    assert client.post('/api/freeze',json={'version':'unapproved'}).status_code==400
    assert client.get('/api/source/UNKNOWN?x0=0&y0=0&x1=100&y1=200').status_code==400
    assert client.get('/',headers={'Host':'attacker.example'}).status_code==403


def test_portable_sources_keep_frozen_identity_without_old_machine_paths(corpus,tmp_path):
    import shutil
    from manga_tool.benchmark.dataset import source_path
    path,dataset,c=corpus;bundle=tmp_path/'portable';bundle.mkdir()
    copied=bundle/'source.png';shutil.copyfile(c['source_files'][0]['path'],copied)
    shutil.copyfile(path,bundle/'dataset.json')
    source=c['source_files'][0]
    (bundle/'source_locations.json').write_text(json.dumps({'dataset_sha256':dataset['dataset_sha256'],'sources':[
        {'chapter_id':'TEST','source_id':source['source_id'],'relative_path':'source.png','sha256':source['sha256']}]}))
    Path(source['path']).rename(Path(source['path']).with_suffix('.moved'))
    moved=load_dataset(bundle/'dataset.json',True)
    assert moved['dataset_sha256']==dataset['dataset_sha256']
    assert source_path(moved,'TEST',source)==copied
    assert create_annotation_app(bundle/'dataset.json').test_client().get('/api/source/TEST?x0=0&y0=0&x1=100&y1=200').status_code==200
    value=json.loads((bundle/'source_locations.json').read_text());value['sources'][0]['sha256']='foreign'
    (bundle/'source_locations.json').write_text(json.dumps(value))
    with pytest.raises(ValueError,match='foreign'):load_dataset(bundle/'dataset.json',True)
