"""Small reliability tests, explicitly not 10-chapter accuracy/stress validation."""
import json
from pathlib import Path
import zipfile

import numpy as np
from PIL import Image
import pytest

from manga_tool.batch import BatchQueue
from manga_tool.benchmark.handoff import package_files,export_workspace
from manga_tool.benchmark.dataset import file_hash


def native_source(tmp_path,name,color):
    path=tmp_path/name;path.mkdir()
    a=np.full((180,120,3),255,np.uint8);a[20:160,10:110]=color
    Image.fromarray(a).save(path/'S0001.png')
    return path


def test_queue_revalidates_completed_source_and_isolates_failures(tmp_path):
    a=native_source(tmp_path,'inputA',[20,50,90]);b=native_source(tmp_path,'inputB',[80,30,40])
    before={p:file_hash(p) for p in [a/'S0001.png',b/'S0001.png']}
    q=BatchQueue(tmp_path/'queue')
    q.initialize({'chapters':[{'chapter_id':'A','input':str(a),'options':{'include_all':True,'generate_contact_sheets':False}},
                              {'chapter_id':'B','input':str(b),'options':{'include_all':True,'generate_contact_sheets':False}}]})
    result=q.run(workers=2)
    assert [j['status'] for j in result['jobs']]==['REVIEW_REQUIRED','REVIEW_REQUIRED']
    assert all(file_hash(p)==v for p,v in before.items())
    for cid in ['A','B']:
        root=tmp_path/'queue/chapters'/cid
        m=json.loads((root/'reports/manifest.json').read_text());assert m['chapter']==cid
        assert not list((root/'approved_artwork').glob('*.png'))
    # A changed input must fail even though A was previously complete. B survives.
    Image.new('RGB',(120,180),'red').save(a/'S0001.png')
    result=q.run()
    assert result['jobs'][0]['status']=='FAILED' and result['jobs'][1]['status']=='REVIEW_REQUIRED'
    assert 'changed' in (tmp_path/'queue/logs/A.log').read_text().lower() or 'fingerprint' in (tmp_path/'queue/logs/A.log').read_text().lower()


def test_queue_identity_paths_and_case_collisions(tmp_path):
    source=native_source(tmp_path,'input',[20,50,90]);q=BatchQueue(tmp_path/'queue')
    q.initialize({'chapters':[{'chapter_id':'A','input':str(source)}]})
    with pytest.raises(ValueError,match='Changed batch'):q.initialize({'chapters':[{'chapter_id':'B','input':str(source)}]})
    with pytest.raises(ValueError,match='safe chapter'):BatchQueue(tmp_path/'two').initialize({'chapters':[{'chapter_id':'CH01','input':str(source)},{'chapter_id':'ch01','input':str(source)}]})
    with pytest.raises(ValueError,match='inside an input'):BatchQueue(source/'bad').initialize({'chapters':[{'chapter_id':'A','input':str(source)}]})
    with pytest.raises(ValueError,match='one or two'):q.run(workers=5)


def test_small_archives_preserve_native_bytes_and_path_index(tmp_path):
    a=tmp_path/'one.bin';a.write_bytes(bytes(range(256))*1500)
    b=tmp_path/'two.bin';b.write_bytes(bytes(range(255,-1,-1))*1500)
    records=package_files([('originals/one.bin',a),('native/two.bin',b)],tmp_path/'parts',max_bytes=500000)
    assert len(records)==2
    for r in records:
        assert r['bytes']<500000
        with zipfile.ZipFile(tmp_path/'parts'/r['filename']) as z:
            assert z.testzip() is None
            for member in r['members']:
                expected=a if member['path'].endswith('one.bin') else b
                assert z.read(member['path'])==expected.read_bytes()
    with pytest.raises(ValueError,match='Unsafe'):package_files([('../bad',a)],tmp_path/'bad')
    with pytest.raises(ValueError,match='exceeds'):package_files([('native/one.bin',a)],tmp_path/'too_small',max_bytes=100000)


def test_portable_manifest_does_not_approve_unreviewed_artwork(tmp_path):
    source=native_source(tmp_path,'input',[20,50,90]);root=tmp_path/'out'
    from manga_tool.pipeline import process_chapter
    m=process_chapter(source,root,chapter='A',include_all=True,generate_contact_sheets=False)
    out=tmp_path/'contract';contract=export_workspace(root,out)
    assert all(p['review_status']!='APPROVED' for p in contract['artworks'])
    exported=json.loads((out/'sources_manifest.json').read_text())
    assert exported['sources'][0]['sha256']==m['sources'][0]['sha256']
    with pytest.raises(ValueError,match='source/revision'):export_workspace(root,root/'originals/contracts')


def test_interrupted_changed_source_does_not_replace_a_valid_package(tmp_path,monkeypatch):
    source=tmp_path/'native.bin';source.write_bytes(b'original bytes')
    out=tmp_path/'parts';package_files([('native.bin',source)],out,max_bytes=100000)
    protected=(out/'evidence_01.zip').read_bytes()
    source.write_bytes(b'new export request')
    write=zipfile.ZipFile.write
    def changed(archive,path,*args,**kwargs):
        result=write(archive,path,*args,**kwargs);Path(path).write_bytes(b'changed during packaging');return result
    monkeypatch.setattr(zipfile.ZipFile,'write',changed)
    with pytest.raises(ValueError,match='changed during packaging'):package_files([('native.bin',source)],out,max_bytes=100000)
    assert (out/'evidence_01.zip').read_bytes()==protected
    assert not list(out.glob('*.tmp'))


def test_actual_chapter_worker_crash_resumes_same_queue_and_sources(tmp_path,monkeypatch):
    source=native_source(tmp_path,'input',[20,50,90]);checksum=file_hash(source/'S0001.png')
    q=BatchQueue(tmp_path/'queue');q.initialize({'chapters':[{'chapter_id':'A','input':str(source),'options':{'include_all':True,'generate_contact_sheets':False}}]})
    monkeypatch.setenv('MANGA_TEST_EXIT_STAGE','INDEX');monkeypatch.setenv('MANGA_TEST_EXIT_AT','1')
    interrupted=q.run();assert interrupted['jobs'][0]['status']=='FAILED'
    monkeypatch.delenv('MANGA_TEST_EXIT_STAGE');monkeypatch.delenv('MANGA_TEST_EXIT_AT')
    recovered=q.run();assert recovered['jobs'][0]['status']=='REVIEW_REQUIRED'
    m=json.loads((tmp_path/'queue/chapters/A/reports/manifest.json').read_text())
    assert m['chapter']=='A' and len(m['sources'])==1 and m['sources'][0]['sha256']==checksum
    assert len({p['id'] for p in m['panels']})==len(m['panels'])
    assert not list((tmp_path/'queue/chapters/A/approved_artwork').glob('*.png'))
