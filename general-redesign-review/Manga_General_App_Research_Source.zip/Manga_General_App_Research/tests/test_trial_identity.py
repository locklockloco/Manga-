import json
from pathlib import Path
import pytest
from PIL import Image

from manga_tool.benchmark.intake import initialize_corpus
from manga_tool.benchmark.trial import run_trial
from manga_tool.benchmark.dataset import fingerprint,atomic_json


def make_corpus(tmp_path,split='development'):
    source=tmp_path/'input';source.mkdir();Image.new('RGB',(180,240),'blue').save(source/'one.png')
    plan=tmp_path/'plan.json';plan.write_text(json.dumps({'chapters':[{'chapter_id':'A','input':'input','include_all':True,'review_windows':1,'split':split}]}))
    path=tmp_path/'corpus/dataset.json';d=initialize_corpus(plan,path)
    return path,d


def test_saved_trial_restarts_without_reprocessing_and_revalidates_originals(tmp_path,monkeypatch):
    path,d=make_corpus(tmp_path);calls=[]
    from manga_tool import detection
    def propose(*args,**kwargs):calls.append(1);return [{'bounds':[0,0,180,240]}],[],[]
    monkeypatch.setattr(detection,'propose_compositions',propose)
    dest=tmp_path/'run';first=run_trial(path,dest,'baseline');assert calls==[1]
    second=run_trial(path,dest,'baseline');assert second==first and calls==[1]
    assert not any(p['human_approved'] for c in second['chapters'] for p in c['outputs'])
    Image.new('RGB',(180,240),'red').save(d['chapters'][0]['source_files'][0]['path'])
    with pytest.raises(ValueError,match='fingerprint'):run_trial(path,dest,'baseline')
    assert calls==[1]


def test_corrupted_completed_checkpoint_is_not_trusted(tmp_path,monkeypatch):
    path,d=make_corpus(tmp_path)
    from manga_tool import detection
    monkeypatch.setattr(detection,'propose_compositions',lambda *a,**k:([{'bounds':[0,0,180,240]}],[],[]))
    dest=tmp_path/'run';run_trial(path,dest,'baseline')
    checkpoint=next((dest/'tasks').glob('*.json'));value=json.loads(checkpoint.read_text());value['payload']['outputs'][0]['bounds']=[0,0,10,10];checkpoint.write_text(json.dumps(value))
    with pytest.raises(ValueError,match='checkpoint'):run_trial(path,dest,'baseline')


def test_holdout_never_enters_development_trial(tmp_path,monkeypatch):
    path,d=make_corpus(tmp_path,split='holdout')
    from manga_tool import detection
    def forbidden(*args,**kwargs):raise AssertionError('Holdout leakage')
    monkeypatch.setattr(detection,'propose_compositions',forbidden)
    result=run_trial(path,tmp_path/'run','baseline')
    assert result['chapters']==[]
