import json
import zipfile
from pathlib import Path
import pytest
from PIL import Image

from manga_tool.benchmark.intake import initialize_corpus
from manga_tool.benchmark.dataset import load_dataset
from manga_tool.importer import import_chapter
from manga_tool.identity import fingerprint_input


def test_cbz_uses_safe_ordered_original_import(tmp_path):
    files=[]
    for name,color in [('strip10.png','red'),('strip2.png','blue')]:
        p=tmp_path/name;Image.new('RGB',(180,240),color).save(p);files.append(p)
    cbz=tmp_path/'test.cbz'
    with zipfile.ZipFile(cbz,'w') as z:
        for p in files:z.write(p,p.name)
    identity=fingerprint_input(cbz,tmp_path/'out')
    imported=import_chapter(cbz,tmp_path/'out',include_all=True)
    assert identity['kind']=='file'
    assert [s['original_name'] for s in imported['sources']]==['strip2.png','strip10.png']


def test_generic_intake_freezes_without_detector_or_approval(tmp_path):
    src=tmp_path/'input';src.mkdir()
    for n in range(4):Image.new('RGB',(180,240),(20+n,40,60)).save(src/f'S{n:04d}.png')
    plan=tmp_path/'plan.json'
    plan.write_text(json.dumps({'chapters':[{'chapter_id':'A','input':'input','include_all':True,'split':'development','review_windows':2},
                                           {'chapter_id':'FUTURE','available':False,'split':'holdout'}]}))
    dest=tmp_path/'corpus/dataset.json'
    d=initialize_corpus(plan,dest)
    assert len(d['chapters'][0]['source_files'])==4 and len(d['tasks'])==2
    assert not d['chapters'][1]['available']
    assert not list(dest.parent.rglob('approved_artwork/*.png'))
    assert initialize_corpus(plan,dest)==d
    Image.new('RGB',(180,240),'black').save(src/'S0000.png')
    with pytest.raises(ValueError,match='changed'):initialize_corpus(plan,dest)


def test_modified_frozen_source_blocks_native_annotation_view(tmp_path):
    # Self-contained to avoid treating supplied manga as a synthetic reference.
    src=tmp_path/'input';src.mkdir();image=src/'one.png';Image.new('RGB',(180,240),'blue').save(image)
    plan=tmp_path/'plan.json';plan.write_text(json.dumps({'chapters':[{'chapter_id':'A','input':'input','include_all':True}]}))
    dest=tmp_path/'corpus/dataset.json';d=initialize_corpus(plan,dest)
    from manga_tool.benchmark.web import create_annotation_app
    client=create_annotation_app(dest).test_client()
    Image.new('RGB',(180,240),'red').save(d['chapters'][0]['source_files'][0]['path'])
    assert client.get('/api/source/A?x0=0&y0=0&x1=180&y1=240').status_code==400
