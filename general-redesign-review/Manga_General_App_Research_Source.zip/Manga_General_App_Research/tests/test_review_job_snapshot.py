"""Public status polling must not report a half-finished worker snapshot."""
import threading
from pathlib import Path
from manga_tool import pipeline,review
from manga_tool.storage import JobPaused


def test_worker_finishing_during_persisted_status_read_stays_running_for_one_poll(tmp_path,monkeypatch):
    source=tmp_path/'source';source.mkdir();output=tmp_path/'output'
    release=threading.Event();threads=[];real_thread=threading.Thread
    def capture(*args,**kwargs):
        thread=real_thread(*args,**kwargs);threads.append(thread);return thread
    def process(*args,**kwargs):
        assert release.wait(10)
        raise JobPaused('fixture preflight reached')
    calls=0
    def status(*args):
        nonlocal calls
        calls+=1
        if calls==1:
            stale={'status':'NEW'}
            release.set();threads[0].join(timeout=2)
            assert not threads[0].is_alive()
            return stale
        return {'status':'PAUSED'}
    monkeypatch.setattr(review.threading,'Thread',capture)
    monkeypatch.setattr(pipeline,'process_chapter',process)
    monkeypatch.setattr(pipeline,'job_status',status)
    client=review.create_app().test_client()
    assert client.post('/api/import',json={'input':str(source),'output':str(output),'preflight':True}).status_code==202
    first=client.get('/api/job').json
    assert first['running'] is True
    next_status=client.get('/api/job').json
    assert next_status['status']=='PAUSED' and next_status['running'] is False


def test_defunct_external_worker_is_resumable_not_reported_running(tmp_path,monkeypatch):
    pid=678901;proc=Path(f'/proc/{pid}/stat');exists=Path.exists;read=Path.read_text
    monkeypatch.setattr(pipeline,'job_status',lambda *args:{'status':'RUNNING','pid':pid})
    monkeypatch.setattr(review.os,'kill',lambda *args:None)
    monkeypatch.setattr(Path,'exists',lambda path:True if path==proc else exists(path))
    monkeypatch.setattr(Path,'read_text',lambda path,*a,**kw:f'{pid} (python) Z 1 2 3' if path==proc else read(path,*a,**kw))
    job=review.create_app(tmp_path).test_client().get('/api/job').json
    assert job['running'] is False and job['interrupted'] is True


def test_uncertain_drawing_text_boundary_gets_review_priority_until_geometry_changes():
    m={'sources':[{'id':'S1','width':100,'height':100}],'joins':[]}
    p={'id':'P1','classification':'illustration','status':'NEEDS_REVIEW','flags':[],
       'source_regions':[{'source_id':'S1','source_bounds':[0,0,100,100]}]}
    assert review.panel_review_risk(p,m)['level']=='routine'
    p['artwork_layers']={'applies_to_current_geometry':True,'uncertain_frame_fringe_pixels':80}
    risk=review.panel_review_risk(p,m)
    assert risk['level']=='high' and 'cutoff' in risk['categories']
    p['artwork_layers']['applies_to_current_geometry']=False
    assert review.panel_review_risk(p,m)['level']=='routine'
