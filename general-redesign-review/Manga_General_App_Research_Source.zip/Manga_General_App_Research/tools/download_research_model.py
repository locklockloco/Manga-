"""Explicit optional research-model download; never runs from application startup."""
import argparse
import hashlib
import os
from pathlib import Path
import urllib.request

URL='https://huggingface.co/Gunnm92/comic-panel-bubble-detection-yolo13n/resolve/891e15bc042279aab8718861e514805ec2dd23bd/onnx/yolo13n_panel-bubble_det_640_op18.onnx'
SIZE=10222514
SHA='506242d8ce2239cf572f3951dafb433ddf630b3df5ab6389b7dd0d1de474a465'


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('destination',type=Path);args=parser.parse_args()
    print('Optional panel/bubble BOX detector: 10,222,514 bytes; model-card license Apache-2.0. Research only; training provenance and artwork quality are not accepted.',flush=True)
    print('Model card: https://huggingface.co/Gunnm92/comic-panel-bubble-detection-yolo13n',flush=True)
    path=args.destination;path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.onnx.tmp')
    try:
        digest=hashlib.sha256();size=0
        with urllib.request.urlopen(URL,timeout=60) as stream,tmp.open('wb') as output:
            while chunk:=stream.read(1024*1024):
                size+=len(chunk)
                if size>SIZE:raise ValueError('Unexpected model size')
                digest.update(chunk);output.write(chunk)
            output.flush();os.fsync(output.fileno())
        if size!=SIZE or digest.hexdigest()!=SHA:raise ValueError('Pinned model checksum/size mismatch; destination not replaced')
        os.replace(tmp,path);print('Verified model saved:',path)
    finally:tmp.unlink(missing_ok=True)


if __name__=='__main__':main()
