"""Compare a fixed gallery set against ORIGINAL source envelopes, not old crops.

Research only, never approval. Every native PNG is extracted from unchanged
source rows; annotated/JPEG views are separate presentation assets.
"""
import argparse,json,sys,hashlib,time
from pathlib import Path
from PIL import Image,ImageDraw
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from manga_tool.artwork_layers import refine_proposals
from manga_tool.chapter import Chapter


def main():
    p=argparse.ArgumentParser();p.add_argument('workspace',type=Path);p.add_argument('cases',type=Path);p.add_argument('output',type=Path)
    args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    raw=args.cases.read_bytes();cases=json.loads(raw)['cases'];manifest=json.loads((args.workspace/'reports/manifest.json').read_text());reader=Chapter(args.workspace,manifest['sources']);results=[];start=time.monotonic()
    original={p['id']:p for p in manifest['panels']}
    class AnalysisChapter:
        root=args.output
        def preview(self,*a,**k):return reader.preview(*a,**k)
        def regions(self,*a,**k):return reader.regions(*a,**k)
    for case in cases:
        old=case['baseline_bounds'];id=case['baseline_id'];panel=original[id]
        envelope=panel.get('composition_graph',{}).get('original_envelope')
        if not envelope:
            raise ValueError(f'{id}: original composition envelope missing; do not silently substitute prior crop bounds')
        if panel.get('source_untrusted') or any(j.get('blocked') and envelope[1]<j['y']<envelope[3] for j in manifest.get('joins',[])):
            raise ValueError(f'{id}: unresolved source alignment; inspect originals before generating comparison crops')
        proposal=refine_proposals(AnalysisChapter(),[{'bounds':list(envelope)}])[0]
        if 'artwork_layers' not in proposal:
            results.append(dict(case,source_analysis_envelope=envelope,status='SOURCE_REVIEW',human_approved=False));continue
        bounds=proposal['bounds'];evidence=proposal['artwork_layers'];native=args.output/(id+'_after.png');reader.save_png(bounds,native)
        before=reader.render(old).convert('RGB');after=reader.render(bounds).convert('RGB')
        scale=min(1,700/max(*before.size,*after.size));w,h=round(before.width*scale),round(before.height*scale);nw,nh=round(after.width*scale),round(after.height*scale)
        comparison=Image.new('RGB',(w+nw+40,max(h,nh)+60),'#ddd');draw=ImageDraw.Draw(comparison)
        comparison.paste(before.resize((w,h)),(10,40));comparison.paste(after.resize((nw,nh)),(w+30,40));draw.text((10,10),id+' EXISTING',fill='black');draw.text((w+30,10),'NEW UNAPPROVED',fill='black');comparison.save(args.output/(id+'_comparison.jpg'),quality=94)
        before.close();after.close()
        results.append(dict(case,source_analysis_envelope=envelope,new_bounds=bounds,source_regions=reader.regions(bounds),sha256=hashlib.sha256(native.read_bytes()).hexdigest(),evidence=evidence,human_approved=False))
    (args.output/'results.json').write_text(json.dumps({'frozen_cases_sha256':hashlib.sha256(raw).hexdigest(),'elapsed_seconds':time.monotonic()-start,'cases':results,'status':'RESEARCH_NOT_RELEASED'},indent=2))


if __name__=='__main__':main()
