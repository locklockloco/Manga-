# Unreleased artwork-boundary research

**Not a release. No GitHub branch or download has been updated. No crop has been human approved.** The earlier integrated report describes the published build, not these working-tree changes.

## Root change

The composition graph still finds candidate scene ranges, but its combined structural envelope is no longer the final artwork crop. `artwork_layers.py` runs a separate boundary stage with four recoverable source-mapped categories: illustrated artwork support, speech/dialogue paper and outlines, standalone text/SFX evidence, and uncertain ink. Background classification is a heuristic canvas hypothesis, not proof that white pixels are dispensable.

Balloon silhouettes are derived from connected light-paper geometry, with OCR and repeated glyph structure as supporting evidence. Both narration rectangles and oval/spiked balloons are considered. Their detected pixels are excluded from the drawing-bound calculation. Complete illustrated support is combined across all substantial components, including neutral details; the largest face or character is never selected as the artwork. Unexplained ink normally remains a protective constraint, so this stage cannot reliably remove every external SFX.

A flat sky or wall does not become a disposable margin merely because it touches the source edge: a proposed large trim also requires optional dialogue or exterior white-paper evidence. The existing chronology uses the original scene anchor, not the moved top edge of a clipped balloon. Monochrome and no-vertical-split fallback paths also receive the boundary stage. Original pixels are never painted, inpainted, erased, resampled for export, or regenerated. The final result is a lossless rectangular extraction of native source rows.

Internal balloon overlap is an explicit rectangle limitation. Cropping cannot reveal hair, background or other original drawing that the author already covered with text. Further removal can require cutting genuine illustration; no clean-removal claim is made in those cases.

## Source-context regression caught during this work

An initial isolated test used the existing integrated crop bounds. It improved the seven exterior-dialogue cases, but this was insufficient evidence for P267: the complete original scene envelope contains thin black balloon tips outside the printed frame. A full-source run caught those tips widening the crop again. That run was cancelled and retained as a rejected experiment; it is not reported as a successful full chapter run.

The corrected stage records small neutral fragments near a confirmed balloon, outside a long straight printed-frame side, as **uncertain exterior fringes**. These fragments retain their original source coordinates and trigger `UNCERTAIN_EXTERIOR_FRAME_FRINGE_REVIEW_REQUIRED`; they are not silently labelled artwork or discarded. The original envelope remains available for expansion/manual correction. This is bounded geometric evidence, not a guarantee that every detached prop can be distinguished from lettering.

All 40 cases are now analyzed from the original composition envelopes and native original strips, with old and new exports compared at a common pixel scale. The same example IDs and the same eight pre-frozen minimum painted-frame rectangles are retained. The frame checks require both preservation and limited outside expansion; passing source pixel hashes alone is not treated as a framing pass.

## Evidence and limits

The experiment is in `/workspace/artwork-boundary-research`. It contains the frozen case list and hashes, original-context overlays, category-mask diagnostics, native proposed crops, side-by-side comparisons, exact source maps, measurements and test logs. The analysis masks are diagnostic images; they are never applied as painted artwork output.

The 40 fixed examples include the user's eight IDs, conversations, multi-character action, weapons, dark scenes, irregular compounds and drawings crossing source strips. All forty before/after comparisons were visually inspected; selected native source frames were inspected more closely. This is an assistant inspection, not human approval or an exhaustive pixel-level semantic segmentation gold set.

Persistent limitations include internal speech overlap (especially P267), exterior diagonal/outlined SFX that remain uncertain (P084/P112/P224), and the existing compound merges (P091/P214). Unknown ink can still hold a margin open. Conversely, uncertain small exterior-frame fragments need review because classical geometry cannot prove their meaning. The program must not call those outputs finished artwork.

The eight frozen frame rectangles support an explicit outside-frame-area measurement. They are not independent exact semantic masks; neither those measurements nor the 40 examples establish whole-chapter precision/recall or prove that every limb, prop and background detail has been recognized. Full-chapter source fidelity, illustration framing, dialogue expansion and manual approval remain separate checks.

Run the source-backed comparison tool:

```
python tools/compare_artwork_layers.py EXISTING_WORKSPACE frozen_40_cases.json RESEARCH_OUTPUT
```

Use a new workspace for a complete detector experiment. Keep existing approved workspaces and their corrections intact. Saved layer analysis is marked stale after manual geometry changes; the source maps are preserved for history rather than being presented as proof about the new crop.

## Final experiment and OCR-only cache

The full R2 run completed pixel/source QA but was rejected as an artwork-framing result: a second portrait retained two tiny neutral balloon-outline fragments above the painted frame. The rule now considers unresolved fragments outside every side of a supported printed frame, not just its left/right sides. That additional portrait is a **regression case discovered during development**, not an unbiased holdout accuracy score. The original forty cases and eight frame references remain unchanged.

The final R6 experiment recomputes all scene grouping, layer geometry, crop bounds, native extraction and pixel QA. It may reuse OCR transcriptions only when the exact RGB bytes, dimensions, executable identity and OCR settings match. Cache records have content checksums, bounded word coordinates and atomic replacement; changed pixels, malformed records and interrupted writes are covered by tests. Five seeded transcriptions were independently recomputed unchanged. No prior crop bounds, class masks or artwork geometry are taken from the rejected run.

An execution-environment restart interrupted an early R3 attempt. The same saved workspace resumed with source identity and fingerprints checked; its unfinished segmentation stage reran. Existing source images, revisions and corrections remained intact. Timing must distinguish the resumed attempt from the cumulative job timing/downtime.

## Compression halos, punctuation and attached SFX

The boundary stage also accounts for outline compression halos without removing adjacent chromatic drawing. Small neutral regions do not become artwork merely because JPEG ringing increases their palette entropy. Large flat-color illustrated compositions remain supported; ambiguous small marks retain source locations.

Centered three-dot punctuation has geometric paper-envelope evidence even when lexical OCR returns no words. Outlined SFX connected to a border receive a separate conservative check: all chromatic islands, a long printed-frame side, a flat outside canvas, and at least four concave outlined-letter interiors must agree before neutral lettering stops widening that side. The excluded material is recorded as source-mapped uncertainty and specifically flagged. Several dark objects, character silhouettes, or convex rectangular weapon vents are insufficient evidence; a negative weapon test preserves those drawings. The ordinary dense-ink envelope is never replaced with a detected-person or face box.

These checks caught regressions when evaluating the original envelopes rather than previously cropped PNGs. The forty fixed examples were rerun without replacing any examples; all eight original frame references and hashes are unchanged. Later additional regression windows were discovered during full-run inspection and used in development, so they are not independent holdout accuracy evidence. For the extra shouting portrait, the original RGB column is white at row 130 and the printed frame begins at row 149; a former component envelope at row 131 included balloon ink and was not treated as artwork gold.

## Thin outlines, review state and actual final run

A narrow white path through a thin JPEG balloon outline could join balloon paper to painted sky. The final mask first opens the light-paper hypothesis with a 3-pixel kernel and uses four-way connectivity. The real P193 conversation regression now keeps both characters and their painted setting; OCR alone does not define the paper envelope.

The local review status endpoint snapshots its worker state before reading persisted state, avoiding a torn snapshot that briefly reported NEW after a fast worker finished. Defunct external worker processes are recognized as interrupted and resumable. Specific uncertain-fringe/frame-inference flags are placed in the cutoff review queue; stale layer evidence after manual geometry changes is excluded. Deterministic tests cover these status/risk cases.

The actual final 194-strip run completed under detector `art-dialogue-layers-research-6`: 213 native PNG proposals, 127 metadata/source-review records, zero VERIFIED. All originals, output hashes and 109,409,903 native output pixels passed fidelity checks. All forty comparisons and all eight protected-frame guards were checked on the final exports. Seven removable exterior-dialogue examples reduced outside-frame area by 95.53%; this is a selected-case framing measure, not whole-chapter accuracy. The original source order is unchanged. The final repository run passed 200 tests, with 11 skipped external-fixture cases and four large synthetic stress entries deselected.

This remains incomplete. P084/P112/P224 retain SFX-driven margins; P126 retains a gray bottom margin even after removing right-side SFX. P091/P214 retain compound scenes, and P274 retains white space between staggered frames. Internal speech overlap, including P267, remains an explicit rectangular-extraction limitation. The forty examples and frozen eight rectangles are assistant-inspected development references, not independently approved semantic gold. No general claim that artwork-first cropping is solved is warranted, and no release or GitHub update has been made. The detailed report and source-paired visual proof are in `/workspace/artwork-boundary-research/RESEARCH_REPORT.md` and `comparison_report.html`.
