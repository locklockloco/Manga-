"""Separate drawing geometry from optional dialogue before choosing rectangles.

Masks are analysis only. They are never painted into exported artwork. This is
classical segmentation evidence, not proof of semantic completeness. Unexplained
ink retains source maps. Flagged exterior-frame fringe proposals require review;
uncertain pixels are not automatically called text or approved as cropped art.
"""
import csv
import io
import hashlib
import json
import os
import uuid
from pathlib import Path
import shutil
import subprocess
import cv2
import numpy as np
from PIL import Image

EXTERIOR, ARTWORK, DIALOGUE, TEXT_SFX, UNCERTAIN = range(5)
CATEGORIES = ['exterior', 'illustrated_artwork', 'speech_dialogue', 'standalone_text_sfx', 'uncertain']


def ocr_words(rgb):
    if not shutil.which('tesseract'):
        return [], 'unavailable'
    stream=io.BytesIO();Image.fromarray(rgb).save(stream,format='PNG')
    try:
        words=[]
        for psm in ['11','6']:
            result=subprocess.run(['tesseract','stdin','stdout','--psm',psm,'tsv'],input=stream.getvalue(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10,check=True)
            for row in csv.DictReader(io.StringIO(result.stdout.decode('utf8','replace')),delimiter='\t'):
                word=row.get('text','').strip();confidence=float(row.get('conf',-1))
                if confidence<55 or len(word)<2 or not any(c.isalpha() for c in word):continue
                x,y,w,h=[int(row[k]) for k in ('left','top','width','height')]
                record={'text':word,'confidence':confidence,'box':[x,y,x+w,y+h]}
                if not any(r['text']==word and abs(r['box'][0]-x)<4 and abs(r['box'][1]-y)<4 for r in words):words.append(record)
        return words,'available'
    except (OSError,subprocess.SubprocessError):return [],'failed_or_timed_out'



def ocr_fingerprint(rgb):
    executable=shutil.which('tesseract')
    engine=None
    if executable:
        st=Path(executable).stat();engine=[executable,st.st_size,st.st_mtime_ns]
    metadata=json.dumps({'contract':'psm11+6_confidence55_v1','shape':list(rgb.shape),'engine':engine},sort_keys=True).encode()
    return hashlib.sha256(metadata+rgb.tobytes()).hexdigest()


def _ocr_words_valid(words,shape):
    if not isinstance(words,list) or len(words)>4096:return False
    h,w=shape[:2]
    try:
        for r in words:
            x,y,xx,yy=r['box'];confidence=float(r['confidence'])
            if not (0<=x<xx<=w and 0<=y<yy<=h and 55<=confidence<=100):return False
            if not isinstance(r['text'],str) or not r['text']:return False
        return True
    except (KeyError,TypeError,ValueError):return False


def write_ocr_cache(rgb,cache,words):
    if not _ocr_words_valid(words,rgb.shape):raise ValueError('Invalid OCR cache words')
    cache=Path(cache);cache.mkdir(parents=True,exist_ok=True);key=ocr_fingerprint(rgb)
    checksum=hashlib.sha256(json.dumps(words,sort_keys=True).encode()).hexdigest()
    data=json.dumps({'fingerprint':key,'words':words,'words_sha256':checksum})
    destination=cache/(key+'.json');temp=cache/(key+'.'+uuid.uuid4().hex+'.tmp')
    try:
        with temp.open('w') as handle:
            handle.write(data);handle.flush();os.fsync(handle.fileno())
        os.replace(temp,destination)
    finally:temp.unlink(missing_ok=True)


def cached_ocr_words(rgb,cache):
    key=ocr_fingerprint(rgb);path=Path(cache)/(key+'.json')
    try:
        if path.stat().st_size>1_000_000:raise ValueError('Oversized OCR cache')
        data=json.loads(path.read_text());words=data['words']
        checksum=hashlib.sha256(json.dumps(words,sort_keys=True).encode()).hexdigest()
        if data['fingerprint']==key and data['words_sha256']==checksum and _ocr_words_valid(words,rgb.shape):
            return words,'available_cached_identical_pixels'
    except (OSError,ValueError,KeyError,TypeError):pass
    words,status=ocr_words(rgb)
    if status=='available':write_ocr_cache(rgb,cache,words)
    return words,status

def _edge_canvas(rgb):
    """Only flat color connected to the outside is an exterior hypothesis."""
    h,w=rgb.shape[:2];a=rgb.astype(np.int16)
    border=np.concatenate([rgb[:3].reshape(-1,3),rgb[-3:].reshape(-1,3),rgb[:,:3].reshape(-1,3),rgb[:,-3:].reshape(-1,3)])
    colors,counts=np.unique(border//12,axis=0,return_counts=True)
    exterior=np.zeros((h,w),bool);records=[]
    for i in np.argsort(counts)[::-1][:6]:
        if counts[i]<len(border)*.055:continue
        color=colors[i].astype(np.int16)*12+6
        match=(np.max(np.abs(a-color),axis=2)<19).astype(np.uint8)
        n,labels,stats,_=cv2.connectedComponentsWithStats(match,8)
        boundary=np.unique(np.concatenate([labels[0],labels[-1],labels[:,0],labels[:,-1]]))
        for j in boundary:
            if not j or stats[j,cv2.CC_STAT_AREA]<max(30,h*w*.001):continue
            exterior|=labels==j
        records.append(color.tolist())
    # External white gutters are paper, regardless of JPEG tint.
    white=(rgb.min(2)>239).astype(np.uint8)
    _,labels,stats,_=cv2.connectedComponentsWithStats(white,8)
    boundary=np.unique(np.concatenate([labels[0],labels[-1],labels[:,0],labels[:,-1]]))
    for j in boundary:
        if j:exterior|=labels==j
    return exterior,records


def _dialogue(rgb,words):
    h,w=rgb.shape[:2];gray=cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY)
    # A paper component contains glyph holes; its external contour recovers the
    # actual balloon silhouette rather than the words' bounding rectangle.
    paper=((gray>224)&(np.ptp(rgb.astype(np.int16),axis=2)<36)).astype(np.uint8)
    # Break tiny white leaks through compressed thin outlines. Four-connected
    # paper complements diagonal black boundaries. The separate outline halo
    # and recoverable fringe logic handle solid/spiked tips after opening.
    paper=cv2.morphologyEx(paper,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
    n,labels,stats,_=cv2.connectedComponentsWithStats(paper,connectivity=4)
    wordmask=np.zeros((h,w),np.uint8)
    for r in words:
        x,y,xx,yy=r['box'];wordmask[max(0,y-4):min(h,yy+4),max(0,x-4):min(w,xx+4)]=1
    candidates={}
    for r in words:
        x,y,xx,yy=r['box'];area=labels[max(0,y-3):min(h,yy+3),max(0,x-3):min(w,xx+3)]
        ids,counts=np.unique(area[area>0],return_counts=True)
        if len(ids):candidates.setdefault(int(ids[counts.argmax()]),[]).append(r)
    mask=np.zeros((h,w),np.uint8);records=[]
    for i in range(1,n):
        inside=candidates.get(i,[])
        x,y,bw,bh,area=map(int,stats[i]);ratio=area/max(1,bw*bh)
        if area<max(300,h*w*.006) or ratio<.50:continue
        strong_ocr=bool(len(inside)>=2 or (len(inside)==1 and inside[0]['confidence']>=78 and len(inside[0]['text'])>=4))
        component=(labels==i).astype(np.uint8)
        contours,_=cv2.findContours(component,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        fill=np.zeros_like(mask);cv2.drawContours(fill,contours,-1,1,-1)
        interior=cv2.erode(fill,np.ones((5,5),np.uint8))>0
        material=(gray<205)|(np.ptp(rgb.astype(np.int16),axis=2)>40)
        unexplained=interior&material&~wordmask.astype(bool)
        geometry_text=False
        if not strong_ocr or unexplained.sum()>max(30,interior.sum()*.055):
            # Stylized/clipped lettering can defeat OCR. Recover a paper
            # envelope only from repeated aligned glyph geometry, with no
            # chromatic artwork inside it. Monochrome scenes stay uncertain.
            ink=((gray<175)&interior).astype(np.uint8)
            ng,_,gs,_=cv2.connectedComponentsWithStats(ink,8)
            glyphs=[g for g in gs[1:] if g[4]>=8 and g[2]>=2 and 7<=g[3]<bh*.42 and g[2]<bw*.65]
            aligned=0
            for g in glyphs:
                cy=g[1]+g[3]/2
                aligned=max(aligned,sum(.5*g[3]<q[3]<1.8*g[3] and abs(q[1]+q[3]/2-cy)<g[3]*.65 for q in glyphs))
            colored=(np.ptp(rgb.astype(np.int16),axis=2)>28)&(rgb.min(2)<235)
            dots=[g for g in glyphs if .35<g[2]/max(1,g[3])<1.5 and g[4]<interior.sum()*.012]
            punctuation=False
            if len(dots)==3:
                centers=np.array([[g[0]+g[2]/2,g[1]+g[3]/2] for g in dots])
                punctuation=bool(np.ptp(centers[:,1])<max(g[3] for g in dots)*.6 and np.ptp(centers[:,0])<bw*.4 and abs(centers[:,0].mean()-(x+bw/2))<bw*.16 and abs(centers[:,1].mean()-(y+bh/2))<bh*.18)
            geometry_text=bool((aligned>=4 or punctuation) and (colored&interior).sum()<interior.sum()*.02 and ink.sum()<interior.sum()*.19 and colored.mean()>.035)
            if not geometry_text:continue
        # Expand just enough to include the outline; source pixels remain intact.
        # Include compressed black outline/antialias fringes, but do not
        # consume adjacent chromatic drawing just to widen a balloon mask.
        radius=max(3,min(9,round(min(h,w)*.012)))
        expanded=cv2.dilate(fill,np.ones((2*radius+1,2*radius+1),np.uint8))
        neutral=(np.ptp(rgb.astype(np.int16),axis=2)<36)|(rgb.min(2)>238)
        fill|=(expanded.astype(bool)&neutral).astype(np.uint8)
        mask|=fill
        records.append({'box':[x,y,x+bw,y+bh],'words':[r['text'] for r in inside],'evidence':'repeated_glyph_paper_geometry' if geometry_text else 'ocr_supported_paper_geometry','unexplained_fraction':float(unexplained.sum()/max(1,interior.sum()))})
    return mask.astype(bool),wordmask.astype(bool),records



def _frame_text_trim(rgb,dialogue,canvas,bounds,padding):
    """Positive repeated lettering outside a supported painted frame.

    This is not an object/face box: ALL chromatic islands contribute. A frame
    side, a flat exterior canvas, and a repeated glyph group must agree before
    attached neutral lettering can stop expanding the illustration rectangle.
    Unrecognized exterior material is retained as source-mapped uncertainty.
    """
    h,w=rgb.shape[:2];gray=cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY)
    chroma=((np.ptp(rgb.astype(np.int16),axis=2)>25)&(rgb.min(2)<238)&~dialogue&~canvas).astype(np.uint8)
    n,labels,stats,_=cv2.connectedComponentsWithStats(chroma,8)
    boxes=[]
    for i,(x,y,bw,bh,area) in enumerate(stats[1:],1):
        if area<max(40,h*w*.00012):continue
        values=rgb[labels==i][::max(1,area//4000)]//24
        if len(np.unique(values,axis=0))<6:continue
        boxes.append([int(x),int(y),int(x+bw),int(y+bh)])
    excluded=np.zeros((h,w),bool);records=[]
    if not boxes:return bounds,excluded,records
    cb=[min(b[0] for b in boxes),min(b[1] for b in boxes),max(b[2] for b in boxes),max(b[3] for b in boxes)]
    edges=cv2.Canny(gray,55,160)
    lines=cv2.HoughLinesP(edges,1,np.pi/180,45,minLineLength=max(35,int(min(h,w)*.28)),maxLineGap=8)
    if lines is None:return bounds,excluded,records
    supported=[False]*4
    for x,y,xx,yy in lines.reshape(-1,4):
        if abs(int(x)-int(xx))<=2 and abs(int(y)-int(yy))>h*.30:
            supported[0]|=abs(int(x)-cb[0])<9;supported[2]|=abs(int(x)-cb[2])<9
        if abs(int(y)-int(yy))<=2 and abs(int(x)-int(xx))>w*.30:
            supported[1]|=abs(int(y)-cb[1])<9;supported[3]|=abs(int(y)-cb[3])<9
    target=[max(0,cb[0]-padding),max(0,cb[1]-padding),min(w,cb[2]+padding),min(h,cb[3]+padding)]
    ink=(gray<200)&~dialogue
    for side in range(4):
        if not supported[side]:continue
        extent=(target[side]-bounds[side]) if side<2 else (bounds[side]-target[side])
        if extent<max(12,(w if side%2==0 else h)*.025):continue
        slab=np.zeros((h,w),bool)
        if side==0:slab[:,:target[0]]=True
        elif side==1:slab[:target[1]]=True
        elif side==2:slab[:,target[2]:]=True
        else:slab[target[3]:]=True
        if not slab.any() or (((rgb.min(2)>238)|canvas)[slab]).mean()<.65:continue
        # Geometry-only trimming needs outlined-letter interiors. Several
        # dark objects or rectangular weapon vents are not enough evidence.
        contours,hierarchy=cv2.findContours((ink&slab).astype(np.uint8),cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
        glyphs=[]
        if hierarchy is not None:
            for i,contour in enumerate(contours):
                parent=hierarchy[0][i][3];depth=0
                while parent>=0:depth+=1;parent=hierarchy[0][parent][3]
                area=cv2.contourArea(contour);hull=cv2.contourArea(cv2.convexHull(contour))
                if depth%2!=1 or area<20 or area/max(1,hull)>.82:continue
                x,y,bw,bh=cv2.boundingRect(contour)
                if 3<=bw<w*.35 and 7<=bh<h*.4:glyphs.append([x,y,bw,bh,area])
        if len(glyphs)<4:continue
        heights=np.array([g[3] for g in glyphs]);median=float(np.median(heights))
        glyphs=[g for g in glyphs if median*.4<=g[3]<=median*2.5]
        if len(glyphs)<4:continue
        centers=np.array([[g[0]+g[2]/2,g[1]+g[3]/2] for g in glyphs])
        eigenvalues=np.linalg.eigvalsh(np.cov(centers.T));ratio=float(eigenvalues[-1]/max(1,eigenvalues[0]))
        if ratio<2.5:continue
        excluded|=slab&((gray<238)|(np.ptp(rgb.astype(np.int16),axis=2)>20))&~dialogue
        bounds[side]=target[side]
        records.append({'side':['left','top','right','bottom'][side],'painted_frame_candidate':cb,'glyph_count':len(glyphs),'glyph_alignment_ratio':ratio,'category':'uncertain_exterior_text_sfx','review_required':True})
    return bounds,excluded,records

def analyze(rgb,padding=4,ocr_cache=None):
    h,w=rgb.shape[:2];a=rgb.astype(np.int16)
    words,ocr=cached_ocr_words(rgb,ocr_cache) if ocr_cache is not None else ocr_words(rgb)
    dialogue,wordmask,balloons=_dialogue(rgb,words)
    canvas,colors=_edge_canvas(rgb)
    # Keep all substantial painted/neutral islands, not just the largest face.
    nonpaper=rgb.min(2)<239
    residual=nonpaper&~canvas&~dialogue
    # Only OCR letters on exterior paper/canvas can be independent text. Words
    # over a painted scene do not punch holes into the drawing support.
    text_only=wordmask&cv2.dilate(canvas.astype(np.uint8),np.ones((9,9),np.uint8)).astype(bool)&~dialogue
    residual&=~text_only
    linked=cv2.morphologyEx(residual.astype(np.uint8),cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
    n,labels,stats,_=cv2.connectedComponentsWithStats(linked,8)
    art=np.zeros((h,w),bool);uncertain=np.zeros((h,w),bool)
    components=[]
    for i,(x,y,bw,bh,area) in enumerate(stats[1:],1):
        region=labels==i
        if area<max(18,h*w*.00010):continue
        vals=rgb[region]
        sample=vals[::max(1,len(vals)//5000)]//24
        _,counts=np.unique(sample,axis=0,return_counts=True)
        entropy=float(-np.sum(counts/counts.sum()*np.log2(counts/counts.sum())))
        chroma=float((np.ptp(vals.astype(np.int16),axis=1)>18).mean())
        substantive=bool(area>=max(100,h*w*.00045) and ((entropy>3.2 and (chroma>.12 or area>=max(600,h*w*.012))) or (chroma>.12 and entropy>2.2 and area>=max(600,h*w*.004)) or (chroma>.20 and area>=h*w*.08)))
        (art if substantive else uncertain)[region]=True
        components.append({'box':[int(x),int(y),int(x+bw),int(y+bh)],'area':int(area),'category':'illustrated_artwork' if substantive else 'uncertain','entropy':round(entropy,3)})
    fringe=np.zeros((h,w),bool)
    ay,ax=np.nonzero(art)
    if len(ax) and dialogue.any() and uncertain.any():
        # Spiked balloons can end in solid black tips with no interior white
        # pixel. Treat only small neutral fragments outside a long printed
        # frame side as unresolved balloon fringes, never as painted extents.
        # They remain source-mapped uncertainty and trigger explicit review.
        core=[int(ax.min()),int(ay.min()),int(ax.max())+1,int(ay.max())+1]
        edge=cv2.Canny(cv2.cvtColor(rgb,cv2.COLOR_RGB2GRAY),55,150)
        lines=cv2.HoughLinesP(edge,1,np.pi/180,55,minLineLength=max(45,int(h*.35)),maxLineGap=7)
        sides=[]
        if lines is not None:
            for x,y,xx,yy in lines.reshape(-1,4):
                if abs(int(x)-int(xx))<=2 and abs(int(y)-int(yy))>=h*.35:
                    if abs(int(x)-core[0])<7:sides.append('left')
                    if abs(int(x)-core[2])<7:sides.append('right')
        distance=cv2.distanceTransform((~dialogue).astype(np.uint8),cv2.DIST_L2,3)
        nu,ul,us,_=cv2.connectedComponentsWithStats(uncertain.astype(np.uint8),8)
        for i,(x,y,bw,bh,area) in enumerate(us[1:],1):
            outside=bool(sides) and (x+bw<core[0] or x>core[2] or y+bh<core[1] or y>core[3])
            if not outside or area>max(100,art.sum()*.004):continue
            region=ul==i;values=rgb[region]
            paper_neighborhood=rgb[max(0,y-5):min(h,y+bh+5),max(0,x-5):min(w,x+bw+5)]
            if (np.ptp(values.astype(np.int16),axis=1)>30).mean()>.10:continue
            if (paper_neighborhood.min(2)>235).mean()<.60:continue
            balloon_span=max((max(b['box'][2]-b['box'][0],b['box'][3]-b['box'][1]) for b in balloons),default=0)
            if distance[region].min()>max(9,w*.055,min(w*.22,balloon_span*.35)):continue
            fringe|=region
    support=art|(uncertain&~fringe)
    yy,xx=np.nonzero(support)
    if len(xx):bounds=[max(0,int(xx.min())-padding),max(0,int(yy.min())-padding),min(w,int(xx.max())+1+padding),min(h,int(yy.max())+1+padding)]
    else:bounds=[0,0,w,h]
    # A uniform painted sky/wall is not an exterior gutter just because it
    # touches the image border. Require optional dialogue or external white
    # paper in a removed slab; otherwise preserve the original composition.
    original=list(bounds)
    slabs=[(slice(0,h),slice(0,bounds[0])),(slice(0,bounds[1]),slice(0,w)),(slice(0,h),slice(bounds[2],w)),(slice(bounds[3],h),slice(0,w))]
    for side,slab in enumerate(slabs):
        pixels=rgb[slab]
        if not pixels.size:continue
        thin=(original[0] if side==0 else original[1] if side==1 else w-original[2] if side==2 else h-original[3])<=max(4,(w if side%2==0 else h)*.018)
        optional=bool(dialogue[slab].mean()>.035 or (pixels.min(2)>239).mean()>.80)
        if not thin and not optional:bounds[side]=[0,0,w,h][side]
    bounds,exterior_text,frame_text_evidence=_frame_text_trim(rgb,dialogue,canvas,bounds,padding)
    art&=~exterior_text;uncertain|=exterior_text;support&=~exterior_text
    # Uncertain regions retain source maps and block automatic acceptance.
    crop=np.zeros((h,w),bool);crop[bounds[1]:bounds[3],bounds[0]:bounds[2]]=True
    labels_out=np.zeros((h,w),np.uint8);labels_out[uncertain]=UNCERTAIN;labels_out[art]=ARTWORK;labels_out[text_only]=TEXT_SFX;labels_out[dialogue]=DIALOGUE
    internal_dialogue=int((dialogue&crop).sum())
    evidence={'method':'separate_art_dialogue_text_uncertainty_layers','categories':CATEGORIES,'ocr':ocr,'words':words,'balloons':balloons,'canvas_colors':colors,'components':components,'original_shape':[w,h],'proposed_bounds':bounds,'support_pixels':int(support.sum()),'retained_support_pixels':int((support&crop).sum()),'frame_text_evidence':frame_text_evidence,'exterior_text_inference_pixels':int(exterior_text.sum()),'uncertain_frame_fringe_pixels':int(fringe.sum()),'uncertain_fringe_resolution':'recoverable_source_locations_require_review' if fringe.any() else None,'dialogue_pixels':int(dialogue.sum()),'dialogue_pixels_inside_rectangle':internal_dialogue,'dialogue_pixels_removed':int((dialogue&~crop).sum()),'rectangular_geometry_limitation':bool(internal_dialogue),'human_verified':False,'semantic_completeness':'UNESTABLISHED','artwork_boundary_expansion_for_dialogue':False}
    return bounds,evidence,labels_out


def refine_proposals(chapter,proposals,padding=4,checkpoint=None):
    """Refine drawing bounds; keep classified layers as recoverable source maps."""
    import math
    output=[]
    for index,p in enumerate(proposals,1):
        if checkpoint:checkpoint('ARTWORK_LAYERS',index,len(proposals),method='separate_art_dialogue_geometry')
        if p.get('metadata_only') or p.get('review_task'):
            output.append(p);continue
        original=list(p['bounds']);p['reading_order_bounds']=list(original)
        if (original[2]-original[0])*(original[3]-original[1])>8_000_000:
            p.setdefault('ambiguity_flags',[]).append('ARTWORK_LAYER_ANALYSIS_TOO_LARGE_REVIEW_REQUIRED')
            output.append(p);continue
        with chapter.preview(original,max_size=1600) as image:rgb=np.asarray(image.convert('RGB'))
        sx=(original[2]-original[0])/rgb.shape[1];sy=(original[3]-original[1])/rgb.shape[0]
        cache=(chapter.root/'review/cache/artwork_ocr') if getattr(chapter,'root',None) is not None else None
        bound,evidence,layers=analyze(rgb,padding=max(2,math.ceil(padding/max(sx,sy))),ocr_cache=cache)
        def native(box):
            return [max(original[0],original[0]+math.floor(box[0]*sx)),max(original[1],original[1]+math.floor(box[1]*sy)),min(original[2],original[0]+math.ceil(box[2]*sx)),min(original[3],original[1]+math.ceil(box[3]*sy))]
        maps={name:[] for name in CATEGORIES[1:]}
        for kind in [ARTWORK,DIALOGUE,TEXT_SFX,UNCERTAIN]:
            binary=(layers==kind).astype(np.uint8)
            n,_,stats,_=cv2.connectedComponentsWithStats(binary,8)
            for x,y,w,h,area in stats[1:]:
                if area<12:continue
                box=native([int(x),int(y),int(x+w),int(y+h)])
                maps[CATEGORIES[kind]].append({'bounds':box,'source_regions':chapter.regions(box),'analysis_pixels':int(area)})
        p['bounds']=native(bound)
        evidence.update(original_envelope=original,native_bounds=p['bounds'],source_layers=maps,analysis_scale=[sx,sy],measurement_scope='Heuristic analysis masks; support retention is not independent proof of illustration completeness.')
        p['artwork_layers']=evidence
        if evidence['frame_text_evidence']:
            p.setdefault('ambiguity_flags',[]).append('EXTERIOR_TEXT_FRAME_INFERENCE_REQUIRES_REVIEW')
        if evidence['uncertain_frame_fringe_pixels']:
            p.setdefault('ambiguity_flags',[]).append('UNCERTAIN_EXTERIOR_FRAME_FRINGE_REVIEW_REQUIRED')
        if evidence['rectangular_geometry_limitation']:
            p.setdefault('ambiguity_flags',[]).append('INTERNAL_DIALOGUE_RECTANGLE_LIMITATION')
        p.setdefault('ambiguity_flags',[]).append('LAYERED_ARTWORK_BOUNDARIES_REQUIRE_REVIEW')
        output.append(p)
    return output
