"""Durable bounded multi-chapter queue around the existing protected pipeline.

Workers are separate processes. A detector crash affects one chapter; neither
queue completion nor child exit codes approve any artwork. Re-running a queue
revalidates even previously completed chapters through the existing identity
and output-repair code before returning saved results.
"""
from __future__ import annotations

from contextlib import contextmanager
import json
import os
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import time

from .benchmark.dataset import canonical, fingerprint
from .storage import writer_lock, utc_now


def pid_alive(pid):
    try:
        os.kill(pid,0)
        stat=Path(f'/proc/{pid}/stat')
        return not(stat.exists() and stat.read_text().split(') ',1)[1].split()[0]=='Z')
    except OSError:
        return False


class BatchQueue:
    def __init__(self, root):
        self.root=Path(root).expanduser().resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.path=self.root/'batch.sqlite3'
        with self.connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS jobs(chapter_id TEXT PRIMARY KEY,position INTEGER UNIQUE NOT NULL,request TEXT NOT NULL,status TEXT NOT NULL,worker_pid INTEGER,error TEXT,updated_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,created_at TEXT NOT NULL,chapter_id TEXT,event TEXT NOT NULL,payload TEXT NOT NULL);
            ''')
            db.execute('INSERT OR IGNORE INTO metadata VALUES(?,?)',('control','run'))

    @contextmanager
    def connect(self):
        db=sqlite3.connect(self.path,timeout=15)
        try:
            db.execute('PRAGMA journal_mode=WAL');db.execute('PRAGMA synchronous=FULL');db.execute('PRAGMA busy_timeout=15000')
            yield db;db.commit()
        except BaseException:
            db.rollback();raise
        finally:db.close()

    def initialize(self,plan):
        jobs=plan.get('chapters',[])
        if not 1<=len(jobs)<=1000:raise ValueError('Provide 1–1000 chapter jobs')
        ids=set();normalized=[]
        allowed={'include_all','min_gutter','padding','vertical','reading_direction','generate_contact_sheets'}
        for position,j in enumerate(jobs):
            cid=j.get('chapter_id','')
            if not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',cid) or cid.casefold() in ids or re.fullmatch(r'(?i:con|prn|aux|nul|com[1-9]|lpt[1-9])',cid):raise ValueError('Unique, cross-platform safe chapter IDs are required')
            ids.add(cid.casefold());source=Path(j['input']).expanduser().resolve()
            if source.is_dir() and self.root.is_relative_to(source):raise ValueError('Batch output must not be inside an input folder')
            options=j.get('options',{})
            if set(options)-allowed:raise ValueError('Unknown chapter processing setting')
            normalized.append({'chapter_id':cid,'input':str(source),'output':str(self.root/'chapters'/cid),'options':options})
        identity=fingerprint(normalized)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row=db.execute('SELECT value FROM metadata WHERE key=?',('plan_sha256',)).fetchone()
            if row and row[0]!=identity:raise ValueError('Changed batch input/order/settings/IDs; use a new queue workspace')
            db.execute('INSERT OR IGNORE INTO metadata VALUES(?,?)',('plan_sha256',identity))
            for position,j in enumerate(normalized):
                db.execute('INSERT OR IGNORE INTO jobs VALUES(?,?,?,?,?,?,?)',(j['chapter_id'],position,canonical(j).decode(),'PENDING',None,None,utc_now()))
        return self.status()

    def status(self):
        with self.connect() as db:
            control=db.execute('SELECT value FROM metadata WHERE key=?',('control',)).fetchone()[0]
            rows=db.execute('SELECT chapter_id,position,request,status,worker_pid,error,updated_at FROM jobs ORDER BY position').fetchall()
        return {'control':control,'jobs':[dict(chapter_id=r[0],position=r[1],request=json.loads(r[2]),status=r[3],worker_pid=r[4],error=r[5],updated_at=r[6]) for r in rows],
                'automatic_artwork_approvals':0,'production_status':'SUPERVISED_REVIEW_REQUIRED'}

    def control(self,action):
        if action not in {'run','pause','cancel'}:raise ValueError('Choose run, pause or cancel')
        with self.connect() as db:
            db.execute('UPDATE metadata SET value=? WHERE key=?',(action,'control'))
            db.execute('INSERT INTO events(created_at,event,payload) VALUES(?,?,?)',(utc_now(),'control',canonical({'action':action}).decode()))
        return self.status()

    def update(self,cid,status,pid=None,error=None):
        with self.connect() as db:
            db.execute('UPDATE jobs SET status=?,worker_pid=?,error=?,updated_at=? WHERE chapter_id=?',(status,pid,error,utc_now(),cid))
            db.execute('INSERT INTO events(created_at,chapter_id,event,payload) VALUES(?,?,?,?)',(utc_now(),cid,status,canonical({'pid':pid,'error':error}).decode()))

    def run(self,workers=1):
        if workers not in {1,2}:raise ValueError('Use one or two isolated CPU workers')
        from .pipeline import job_control,job_status
        with writer_lock(self.root):
            state=self.status()
            if not state['jobs']:raise ValueError('Initialize a chapter plan first')
            if any(j['worker_pid'] and pid_alive(j['worker_pid']) for j in state['jobs']):
                raise ValueError('A saved chapter worker is still active; inspect status/control before restarting the parent')
            # Includes complete jobs: child pipeline must revalidate source bytes and repair exports.
            pending=list(state['jobs']);active={};self.control('run')
            logs=self.root/'logs';logs.mkdir(exist_ok=True)
            while pending or active:
                control=self.status()['control']
                if control!='run':
                    for proc,j,log in active.values():
                        try:job_control(j['request']['output'],control)
                        except (OSError,ValueError):pass
                    if not active:break
                while control=='run' and pending and len(active)<workers:
                    j=pending.pop(0);req=j['request'];cid=j['chapter_id']
                    request_file=self.root/'requests'/(cid+'.json');request_file.parent.mkdir(exist_ok=True)
                    from .benchmark.dataset import atomic_json
                    atomic_json(request_file,req)
                    log=(logs/(cid+'.log')).open('ab')
                    env=os.environ.copy();env['OMP_THREAD_LIMIT']='1';env['OPENBLAS_NUM_THREADS']='1'
                    package=str(Path(__file__).resolve().parents[1]);env['PYTHONPATH']=package+os.pathsep+env.get('PYTHONPATH','')
                    proc=subprocess.Popen([sys.executable,'-m','manga_tool.batch','_worker',str(request_file)],stdout=log,stderr=subprocess.STDOUT,env=env)
                    active[cid]=(proc,j,log);self.update(cid,'RUNNING',proc.pid)
                for cid,(proc,j,log) in list(active.items()):
                    code=proc.poll()
                    if code is None:continue
                    log.close()
                    try:child=job_status(j['request']['output'])
                    except (OSError,ValueError):child={}
                    status='REVIEW_REQUIRED' if code==0 else child.get('status') if child.get('status') in {'PAUSED','CANCELLED'} else 'FAILED'
                    self.update(cid,status,error=None if code==0 else child.get('error') or f'Worker exited {code}; inspect logs/{cid}.log')
                    del active[cid]
                if active:time.sleep(.2)
            return self.status()


def worker(request_file):
    from .pipeline import process_chapter
    request=json.loads(Path(request_file).read_text())
    process_chapter(request['input'],request['output'],chapter=request['chapter_id'],**request['options'])


def main(argv=None):
    import argparse
    argv=sys.argv[1:] if argv is None else argv
    if argv and argv[0]=='_worker':
        worker(argv[1]);return
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path)
    parser.add_argument('--plan',type=Path);parser.add_argument('--run',action='store_true');parser.add_argument('--workers',type=int,default=1)
    parser.add_argument('--control',choices=['run','pause','cancel']);args=parser.parse_args(argv)
    queue=BatchQueue(args.root)
    if args.plan:queue.initialize(json.loads(args.plan.read_text()))
    if args.control:queue.control(args.control)
    print(json.dumps(queue.run(args.workers) if args.run else queue.status(),indent=2))


if __name__=='__main__':main()
