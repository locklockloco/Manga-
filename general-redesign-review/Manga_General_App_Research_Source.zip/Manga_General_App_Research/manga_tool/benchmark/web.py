"""Loopback-only source labeling interface; no detector can set verified here."""
import io
from pathlib import Path
from urllib.parse import urlparse

from flask import Flask, jsonify, request, send_file

from ..chapter import Chapter
from .annotations import AnnotationStore
from .dataset import atomic_json, load_dataset, valid_box, file_hash, source_path


def create_annotation_app(dataset_path, database=None):
    store = AnnotationStore(dataset_path, database)
    dataset = store.dataset
    chapters = {c['chapter_id']:c for c in dataset['chapters']}
    app = Flask(__name__, static_folder='static', static_url_path='/static')
    app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024

    @app.before_request
    def local_only():
        if urlparse('http://'+request.host).hostname not in {'localhost','127.0.0.1','::1'}:
            return jsonify(error='Local annotation server only'), 403
        origin = request.headers.get('Origin')
        if origin and urlparse(origin).netloc != request.host:
            return jsonify(error='Cross-origin edits are disabled'), 403

    @app.after_request
    def headers(response):
        response.headers['Cache-Control'] = 'no-store'
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Content-Security-Policy'] = "default-src 'self'; img-src 'self' blob:; style-src 'self'; script-src 'self'; frame-ancestors 'none'"
        return response

    @app.errorhandler(ValueError)
    def invalid(error):
        return jsonify(error=str(error)), 400

    @app.get('/')
    def index():
        return app.send_static_file('annotation.html')

    @app.get('/api/corpus')
    def corpus():
        return jsonify(dataset=dataset, annotations=store.all(),
                       note='All proposed labels remain drafts until a named human completes the source review checklist. No application crop approval is changed.')

    @app.get('/api/source/<chapter_id>')
    def source(chapter_id):
        if chapter_id not in chapters or not chapters[chapter_id].get('available'):
            raise ValueError('Chapter is not available; no holdout pixels have been supplied')
        chapter = chapters[chapter_id]
        bounds = [int(request.args[k]) for k in ['x0','y0','x1','y1']]
        valid_box(bounds, chapter['image_width'], chapter['image_height'])
        if (bounds[2]-bounds[0])*(bounds[3]-bounds[1]) > 12_000_000:
            raise ValueError('View a source window of at most 12 MP; pan to the neighboring range')
        for source in chapter['source_files']:
            if max(bounds[1],source['y0']) < min(bounds[3],source['y1']) and file_hash(source_path(dataset,chapter_id,source)) != source['sha256']:
                raise ValueError('Original source changed; do not label stale coordinates')
        sources = [dict(s, id=s['source_id'], path=str(source_path(dataset,chapter_id,s)), mode='RGB') for s in chapter['source_files']]
        # Opening source imagery never mutates a job or a reference annotation.
        with Chapter(Path('/'), sources).render(bounds) as image:
            stream = io.BytesIO(); image.save(stream, format='PNG'); stream.seek(0)
        return send_file(stream, mimetype='image/png')

    @app.post('/api/annotations')
    def save():
        data = request.get_json()
        return jsonify(store.save(data['annotation'], data.get('expected_revision',0)))

    @app.post('/api/restore')
    def restore():
        data = request.get_json()
        return jsonify(store.restore(data['id'],int(data['revision']),int(data['expected_revision'])))

    @app.post('/api/exhaustive')
    def exhaustive():
        data = request.get_json()
        return jsonify(store.confirm_exhaustive(data['chapter_id'],data.get('reviewer',''),data.get('confirm')))

    @app.get('/api/gold')
    def export():
        return jsonify(store.export())

    @app.post('/api/freeze')
    def freeze():
        data = request.get_json()
        version = data.get('version','')
        path = Path(dataset_path).parent/'gold'/(version+'.json')
        gold = store.freeze(version,path,data.get('amendment'))
        return jsonify(gold)

    return app
