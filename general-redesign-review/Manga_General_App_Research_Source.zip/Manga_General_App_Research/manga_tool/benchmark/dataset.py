"""Immutable corpus/split records and source-referenced annotation contracts."""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import tempfile

from PIL import Image

SCHEMA = '1.1'
KINDS = {'artwork', 'text_only', 'standalone_sfx', 'narration_only', 'ambiguous'}
LAYERS = {'artwork', 'dialogue', 'sfx', 'narration', 'exterior_paper', 'intentional_blank', 'uncertain_ink'}


class FrozenDataset(dict):
    """JSON content stays frozen; runtime storage locations live outside its hash."""
    locations = None


def source_path(dataset, chapter_id, source):
    locations = getattr(dataset, 'locations', None) or {}
    return Path(locations.get((chapter_id, source['source_id']), source['path']))


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode()


def fingerprint(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def file_hash(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(canonical(value))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
    finally:
        Path(tmp).unlink(missing_ok=True)


def valid_box(value, width, height):
    if not isinstance(value, list) or len(value) != 4 or any(type(v) is not int for v in value):
        raise ValueError('Bounds must contain four integer native pixel coordinates')
    x, y, xx, yy = value
    if not (0 <= x < xx <= width and 0 <= y < yy <= height):
        raise ValueError('Empty or out-of-source bounds')
    return value


def source_regions(chapter, bounds):
    x, y, xx, yy = valid_box(bounds, chapter['image_width'], chapter['image_height'])
    result = []
    for source in chapter['source_files']:
        top, bottom = max(y, source['y0']), min(yy, source['y1'])
        right = min(xx, source['width'])
        if top < bottom and x < right:
            result.append({'source_id': source['source_id'], 'filename': source['filename'],
                           'sha256': source['sha256'], 'source_order': source['order'],
                           'source_bounds': [x, top-source['y0'], right, bottom-source['y0']],
                           'chapter_bounds': [x, top, right, bottom]})
    if not result:
        raise ValueError('Region contains no original source pixels')
    return result


def chapter_from_workspace(workspace, chapter_id, split='development', style='unspecified', acquisition='native_strips'):
    root = Path(workspace).resolve()
    manifest = json.loads((root / 'reports/manifest.json').read_text())
    records = []
    for source in manifest['sources']:
        path = (root / source['path']).resolve()
        if not path.is_relative_to(root):
            raise ValueError('Source path escapes workspace')
        actual = file_hash(path)
        if actual != source['sha256']:
            raise ValueError(f'Changed source: {source["id"]}')
        with Image.open(path) as image:
            image.verify()
        with Image.open(path) as image:
            if image.size != (source['width'], source['height']):
                raise ValueError('Source dimensions differ from saved mapping')
        records.append({'source_id': source['id'], 'filename': source['original_name'], 'path': str(path),
                        'sha256': actual, 'bytes': path.stat().st_size, 'width': source['width'],
                        'height': source['height'], 'order': source['order'], 'y0': source['y0'],
                        'y1': source['y1'], 'discontinuity_before': source.get('discontinuity_before', [])})
    if len({s['source_id'] for s in records}) != len(records):
        raise ValueError('Duplicate source IDs within chapter')
    records.sort(key=lambda s: s['order'])
    if not records or records[0]['y0'] != 0 or any(a['y1'] != b['y0'] for a,b in zip(records, records[1:])):
        raise ValueError('Non-contiguous source coordinate map')
    return {'chapter_id': chapter_id, 'split': split, 'style': style, 'available': True,
            'acquisition': acquisition, 'workspace': str(root), 'reading_direction': manifest.get('reading_direction', 'ltr'),
            'image_width': max(s['width'] for s in records), 'image_height': records[-1]['y1'],
            'source_files': records, 'exhaustively_labeled': False}


def freeze_dataset(destination, chapters, tasks, provenance):
    ids = [c['chapter_id'] for c in chapters]
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate chapter IDs')
    if any(c['split'] not in {'development', 'validation', 'holdout', 'cross_style_holdout'} for c in chapters):
        raise ValueError('Unknown split')
    by_id = {c['chapter_id']: c for c in chapters}
    if len({t['id'] for t in tasks}) != len(tasks):
        raise ValueError('Duplicate annotation task IDs')
    for task in tasks:
        c = by_id[task['chapter_id']]
        valid_box(task['bounds'], c['image_width'], c['image_height'])
        task['source_regions'] = source_regions(c, task['bounds'])
    content = {'schema_version': SCHEMA, 'chapters': chapters, 'tasks': tasks, 'provenance': provenance,
               'annotation_truth': 'NO_HUMAN_VERIFIED_LABELS_AT_FREEZE', 'production_ready': False}
    value = {**content, 'dataset_sha256': fingerprint(content)}
    path = Path(destination)
    if path.exists() and json.loads(path.read_text()) != value:
        raise ValueError('Frozen dataset differs; create a new version with a written amendment')
    atomic_json(path, value)
    return value


def load_dataset(path, verify_sources=False):
    value = json.loads(Path(path).read_text())
    expected = value.pop('dataset_sha256')
    if value.get('schema_version') != SCHEMA or fingerprint(value) != expected:
        raise ValueError('Dataset metadata hash/schema mismatch')
    value['dataset_sha256'] = expected
    value = FrozenDataset(value)
    relocation = Path(path).resolve().parent/'source_locations.json'
    if relocation.exists():
        mapped = json.loads(relocation.read_text())
        if mapped.get('dataset_sha256') != expected:
            raise ValueError('Source relocation belongs to a different frozen corpus')
        wanted = {(c['chapter_id'],s['source_id']):s for c in value['chapters'] for s in c.get('source_files',[])}
        locations = {}
        for item in mapped.get('sources',[]):
            key = (item['chapter_id'],item['source_id'])
            if key not in wanted or key in locations or item['sha256'] != wanted[key]['sha256']:
                raise ValueError('Duplicate/foreign source in relocation map')
            actual = (relocation.parent/item['relative_path']).resolve()
            if not actual.is_relative_to(relocation.parent):
                raise ValueError('Relocated source escapes evidence folder')
            locations[key] = str(actual)
        if set(locations) != set(wanted):
            raise ValueError('Relocation must map every source, not silently mix chapters or machines')
        value.locations = locations
    if verify_sources:
        for chapter in value['chapters']:
            for source in chapter.get('source_files', []):
                if file_hash(source_path(value,chapter['chapter_id'],source)) != source['sha256']:
                    raise ValueError(f'Source fingerprint mismatch: {chapter["chapter_id"]}/{source["source_id"]}')
    return value


def validate_annotation(value, chapter):
    value = json.loads(canonical(value))
    if value.get('chapter_id') != chapter['chapter_id'] or value.get('kind') not in KINDS:
        raise ValueError('Annotation chapter/kind mismatch')
    if not isinstance(value.get('id'), str) or not 1 <= len(value['id']) <= 120:
        raise ValueError('Annotation needs a stable ID')
    w, h = chapter['image_width'], chapter['image_height']
    valid_box(value['bounds'], w, h)
    if value.get('kind') == 'artwork':
        valid_box(value.get('ideal_crop_bounds'), w, h)
    for box in value.get('must_keep_boxes', []):
        valid_box(box, w, h)
    for layer in value.get('layers', []):
        if layer.get('kind') not in LAYERS:
            raise ValueError('Unknown drawing/dialogue layer')
        polygon = layer.get('polygon', [])
        if not 3 <= len(polygon) <= 2048:
            raise ValueError('A layer polygon needs 3–2048 vertices')
        for point in polygon:
            if len(point) != 2 or any(type(v) is not int for v in point) or not (0 <= point[0] < w and 0 <= point[1] < h):
                raise ValueError('Polygon vertices must be original native source pixels')
        if layer['kind'] == 'artwork' and any(not(value['bounds'][0] <= x < value['bounds'][2] and value['bounds'][1] <= y < value['bounds'][3]) for x,y in polygon):
            raise ValueError('Required artwork polygon lies outside required bounds')
    if value.get('verified') is True:
        checklist = value.get('review_checklist', {})
        if value.get('reviewer_role') != 'human' or not str(value.get('verified_by') or '').strip():
            raise ValueError('Only an explicit named human annotation review can verify a label')
        if not all(checklist.get(k) is True for k in ['native_source_inspected', 'neighbors_checked', 'complete_composition_checked', 'optional_text_checked']):
            raise ValueError('Complete the native-source and composition review checklist')
        if value['kind'] == 'ambiguous':
            raise ValueError('Adjudicate ambiguity before creating a hard gold label')
    else:
        value['verified'] = False
        value['verified_by'] = None
    value['source_regions'] = source_regions(chapter, value['bounds'])
    return value
