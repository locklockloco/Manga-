"""Human-reference evaluator: mask retention, scene errors and explicit gates.

Unlike the kit's unchanged starter scorer, this validates source identity,
separates mask/box evidence, checks unions of split fragments, and provides
Wilson intervals for instance rates. These are still annotation-based proxies,
not a machine assertion of visual correctness or human approval.
"""
from __future__ import annotations

import math
from PIL import Image, ImageDraw
import numpy as np

from .dataset import fingerprint, source_regions, valid_box, validate_annotation, file_hash, source_path


def area(box):
    return (box[2]-box[0])*(box[3]-box[1])


def overlap(a, b):
    return max(0, min(a[2], b[2])-max(a[0], b[0]))*max(0, min(a[3], b[3])-max(a[1], b[1]))


def wilson(successes, total):
    if not total:
        return None
    z = 1.959963984540054
    p = successes/total
    scale = 1+z*z/total
    center = (p+z*z/(2*total))/scale
    half = z*math.sqrt(p*(1-p)/total+z*z/(4*total*total))/scale
    return [max(0, center-half), min(1, center+half)]


def retention(annotation, boxes):
    """Native mask union coverage, streaming 256-row tiles, or explicit bbox proxy."""
    polygons = [p['polygon'] for p in annotation.get('layers', []) if p['kind'] == 'artwork']
    required = annotation['bounds']
    total = kept = 0
    width = required[2]-required[0]
    if width > 20000:
        raise ValueError('Reference mask exceeds the evaluator width budget')
    for y in range(required[1], required[3], 256):
        end = min(y+256, required[3]); shape = (width, end-y)
        mask = Image.new('1', shape, not polygons)
        if polygons:
            draw = ImageDraw.Draw(mask)
            for points in polygons:
                draw.polygon([(x-required[0], yy-y) for x,yy in points], fill=1)
        visible = Image.new('1', shape, 0); draw = ImageDraw.Draw(visible)
        for x0,y0,x1,y1 in boxes:
            left, top, right, bottom = max(x0,required[0]), max(y0,y), min(x1,required[2]), min(y1,end)
            if left < right and top < bottom:
                draw.rectangle((left-required[0],top-y,right-required[0]-1,bottom-y-1), fill=1)
        a = np.asarray(mask, dtype=bool); b = np.asarray(visible, dtype=bool)
        total += int(a.sum()); kept += int((a & b).sum())
    if not total:
        raise ValueError('Empty required artwork reference mask')
    return kept/total, total, 'native_polygon_mask' if polygons else 'bounding_rectangle_proxy'


def evaluate(dataset, gold, prediction):
    digest = dataset['dataset_sha256']
    for chapter in dataset['chapters']:
        for source in chapter.get('source_files', []):
            if file_hash(source_path(dataset,chapter['chapter_id'],source)) != source['sha256']:
                raise ValueError('Actual original source fingerprint changed; do not score stale coordinates')
    if gold.get('dataset_sha256') != digest or prediction.get('dataset_sha256') != digest:
        raise ValueError('Gold/predictions use different frozen source corpus or split')
    if gold.get('gold_sha256'):
        content = {k:v for k,v in gold.items() if k != 'gold_sha256'}
        if fingerprint(content) != gold['gold_sha256']:
            raise ValueError('Frozen human labels have changed')
    chapters = {c['chapter_id']: c for c in dataset['chapters']}
    by_gold = {c['chapter_id']: c for c in gold.get('chapters', [])}
    by_pred = {c['chapter_id']: c for c in prediction.get('chapters', [])}
    if len(by_gold) != len(gold.get('chapters', [])) or len(by_pred) != len(prediction.get('chapters', [])):
        raise ValueError('Duplicate chapter IDs')
    if set(by_gold)-set(chapters) or set(by_pred)-set(chapters):
        raise ValueError('Unknown chapter in labels/predictions')
    results = []
    for cid, chapter in chapters.items():
        supplied = by_gold.get(cid, {})
        labels = [a for a in supplied.get('annotations', []) if a.get('verified') is True and not a.get('withdrawn')]
        if supplied.get('source_files', chapter.get('source_files', [])) != chapter.get('source_files', []):
            raise ValueError('Gold source map differs from frozen dataset')
        if len({a['id'] for a in labels}) != len(labels):
            raise ValueError('Duplicate reference instance IDs')
        labels = [validate_annotation(a, chapter) for a in labels]
        pred = by_pred.get(cid, {})
        all_outputs = pred.get('outputs', [])
        if len({p['id'] for p in all_outputs}) != len(all_outputs):
            raise ValueError('Duplicate prediction IDs')
        for output in all_outputs+pred.get('review_tasks', []):
            valid_box(output['bounds'], chapter['image_width'], chapter['image_height'])
            if output.get('source_regions') != source_regions(chapter, output['bounds']):
                raise ValueError('Prediction source map/hash/coordinates mismatch')
            if output.get('human_approved'):
                raise ValueError('Research detector outputs cannot approve themselves')
        if not labels:
            results.append({'chapter_id': cid, 'split': chapter['split'], 'available': chapter.get('available'),
                            'status': 'INSUFFICIENT_HUMAN_VERIFIED_GOLD', 'verified_artworks': 0,
                            'artwork_recall': None, 'artwork_precision': None, 'required_drawing_retention': None,
                            'proposal_count': len(all_outputs), 'message': 'No numeric quality score; original sources and predictions are available for independent annotation.'})
            continue
        artworks = [a for a in labels if a['kind'] == 'artwork']
        negatives = [a for a in labels if a['kind'] in {'text_only','standalone_sfx','narration_only'}]
        exported = [p for p in all_outputs if p.get('kind') == 'artwork' and p.get('status') == 'exported']
        reviews = [p for p in all_outputs+pred.get('review_tasks', []) if p.get('status') == 'needs_review']
        matches = {a['id']:[] for a in artworks}; crop_matches = {p['id']:[] for p in exported}
        cover = {}
        for a in artworks:
            for p in exported:
                fraction, total, method = retention(a, [p['bounds']])
                cover[(a['id'],p['id'])] = (fraction,total,method)
                if fraction >= .90:
                    matches[a['id']].append(p)
                    crop_matches[p['id']].append(a['id'])
        merges = [p['id'] for p in exported if len(crop_matches[p['id']]) > 1]
        complete, clipped, excess, splits, missing, review_only, detail = [], [], [], [], [], [], []
        mask_retained = mask_total = all_mask_total = all_mask_retained = 0
        duplicate = []
        for a in artworks:
            candidates = matches[a['id']]
            if any(layer['kind']=='artwork' for layer in a.get('layers',[])):
                fractions=[retention(a,[p['bounds']]) for p in exported]
                best=max(fractions,key=lambda r:r[0]) if fractions else retention(a,[])
                all_mask_total+=best[1];all_mask_retained+=round(best[0]*best[1])
            if len(candidates) > 1:
                duplicate.append(a['id'])
            valid = []
            for p in candidates:
                fraction,total,method = cover[(a['id'],p['id'])]
                guards = a.get('must_keep_boxes', [])
                # Important small parts cannot vanish behind a favorable total mask average.
                guard_ok = all(overlap(b,p['bounds']) == area(b) for b in guards)
                ideal = a['ideal_crop_bounds']; outside = (area(p['bounds'])-overlap(p['bounds'],ideal))/area(ideal)
                if fraction < .995 or not guard_ok:
                    clipped.append({'artwork_id': a['id'], 'crop_id': p['id'], 'retention': fraction, 'must_keep_boxes_retained': guard_ok})
                if outside > float(a.get('max_excess_area_ratio',.20)):
                    excess.append({'artwork_id': a['id'], 'crop_id': p['id'], 'outside_ideal_area_ratio': outside})
                if len(crop_matches[p['id']]) == 1 and fraction >= .995 and guard_ok and outside <= float(a.get('max_excess_area_ratio',.20)):
                    valid.append(p)
            if len(candidates) == 1 and len(valid) == 1:
                complete.append(a['id'])
                fraction,total,method = cover[(a['id'],valid[0]['id'])]
                if method == 'native_polygon_mask':
                    mask_total += total; mask_retained += round(fraction*total)
            fragments = [p for p in exported if overlap(p['bounds'],a['bounds'])/area(a['bounds']) >= .05]
            for fragment in fragments:
                fraction,_,_=retention(a,[fragment['bounds']])
                if .05 <= fraction < .90:
                    clipped.append({'artwork_id':a['id'],'crop_id':fragment['id'],
                                    'retention':fraction,'severity':'fragment_may_cut_composition'})
            union_fraction,_,method = retention(a, [p['bounds'] for p in fragments])
            if not candidates and len(fragments) > 1 and union_fraction >= .995:
                splits.append(a['id'])
            referred = any(retention(a,[p['bounds']])[0] >= .995 for p in reviews)
            if a['id'] not in complete and referred:
                review_only.append(a['id'])
            if not candidates and not referred and union_fraction < .995:
                missing.append(a['id'])
            detail.append({'artwork_id':a['id'], 'matching_crop_ids':[p['id'] for p in candidates],
                           'complete':a['id'] in complete, 'review_routed':referred,
                           'reference_evidence':method, 'fragment_union_retention':union_fraction})
        false_text = [{'negative_id':n['id'], 'crop_id':p['id']} for n in negatives for p in exported
                      if overlap(n['bounds'],p['bounds'])/area(n['bounds']) >= .80 and not crop_matches[p['id']]]
        review = supplied.get('exhaustive_review') or {}
        exhaustive = supplied.get('exhaustively_labeled') is True and review.get('reviewer_role') == 'human' and bool(review.get('reviewer'))
        correct_exports = sum(len(crop_matches[p['id']]) == 1 and crop_matches[p['id']][0] in complete for p in exported)
        results.append({'chapter_id':cid, 'split':chapter['split'], 'style':chapter.get('style'),
            'status':'ANNOTATION_PROXY_NOT_HUMAN_CROP_APPROVAL', 'verified_artworks':len(artworks),
            'verified_negatives':len(negatives), 'correct_complete_instances':len(complete),
            'artwork_exports':len(exported), 'artwork_recall':len(complete)/len(artworks) if artworks else None,
            'recall_95pct_wilson':wilson(len(complete),len(artworks)),
            'artwork_precision':correct_exports/len(exported) if exhaustive and exported else None,
            'precision_95pct_wilson':wilson(correct_exports,len(exported)) if exhaustive else None,
            'precision_note':'Only an explicitly human-reviewed exhaustive chapter supports export precision.',
            'mask_retention_complete_outputs':mask_retained/mask_total if mask_total else None,
            'mask_annotated_pixels_in_complete_outputs':mask_total,
            'mask_retention_best_single_rectangle_all_instances':all_mask_retained/all_mask_total if all_mask_total else None,
            'all_reference_mask_pixels':all_mask_total,
            'predicted_mask_iou':None,
            'predicted_mask_iou_note':'Current baseline and learned feasibility adapters provide rectangles, not independently predicted semantic masks. This gate is untested.',
            'merged_crop_ids':merges, 'split_artwork_ids':splits, 'duplicate_artwork_ids':duplicate,
            'possible_cuts':clipped, 'excess_exterior':excess, 'missed_artwork_ids':missing,
            'review_routed_not_success':review_only, 'false_text_exports':false_text,
            'review_fraction':len(review_only)/len(artworks) if artworks else None,
            'exhaustively_labeled':exhaustive, 'instances':detail})
    measured = [c for c in results if c.get('verified_artworks')]
    holdouts = [c for c in measured if c['split'] in {'holdout','cross_style_holdout'}]
    return {'scorer_version':'1.0-source-mask-scene-proxy', 'dataset_sha256':digest,
            'chapters':results, 'numerically_evaluated_chapters':len(measured),
            'release_gate':{'status':'BLOCKED', 'human_signoff':False,
                'reasons':['Independent, exhaustive held-out chapters and cross-style acceptance are required.',
                           'No automatic success or production approval is derived from this evaluator.'] +
                          (['No human-verified artwork labels are present.'] if not measured else []) +
                          (['No scored holdout chapters are present.'] if not holdouts else [])},
            'warning':'Per-window predictions may overlap. Do not treat window duplicates as distinct artwork or a whole-chapter score.'}
