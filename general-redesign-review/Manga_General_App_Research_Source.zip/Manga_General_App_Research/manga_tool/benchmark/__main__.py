"""Research commands are integrated with the existing app, not a new detector release."""
import argparse
import json
from pathlib import Path
import threading
import webbrowser


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest='command',required=True)
    init=sub.add_parser('init-corpus',help='Freeze source hashes/splits before detector inference')
    init.add_argument('plan',type=Path);init.add_argument('-o','--output',required=True,type=Path)
    annotate=sub.add_parser('annotate',help='Native-source boxes/polygons and explicit human reference review')
    annotate.add_argument('dataset',type=Path);annotate.add_argument('--port',type=int,default=8766);annotate.add_argument('--no-browser',action='store_true')
    run=sub.add_parser('trial',help='Frozen development windows only; never approves crops')
    run.add_argument('dataset',type=Path);run.add_argument('-o','--output',required=True,type=Path)
    run.add_argument('--candidate',choices=['baseline','learned','hybrid'],required=True)
    run.add_argument('--weights',type=Path);run.add_argument('--cpu',action='store_true',default=True)
    run.add_argument('--max-tasks',type=int)
    score=sub.add_parser('evaluate',help='Report no score unless human-verified labels exist')
    score.add_argument('dataset',type=Path);score.add_argument('--gold',type=Path);score.add_argument('--pred',type=Path,required=True);score.add_argument('-o','--output',type=Path,required=True)
    labels=sub.add_parser('export-labels');labels.add_argument('dataset',type=Path);labels.add_argument('-o','--output',required=True,type=Path)
    freeze=sub.add_parser('freeze-labels');freeze.add_argument('dataset',type=Path);freeze.add_argument('--version',required=True);freeze.add_argument('--amendment');freeze.add_argument('-o','--output',type=Path,required=True)
    exhaustive=sub.add_parser('confirm-exhaustive');exhaustive.add_argument('dataset',type=Path);exhaustive.add_argument('--chapter',required=True);exhaustive.add_argument('--reviewer',required=True);exhaustive.add_argument('--human-confirm-entire-chapter-inspected',action='store_true')
    handoff=sub.add_parser('export-contract');handoff.add_argument('workspace',type=Path);handoff.add_argument('-o','--output',required=True,type=Path)
    args=parser.parse_args(argv)
    from .dataset import atomic_json,load_dataset
    from .annotations import AnnotationStore
    try:
        if args.command=='init-corpus':
            from .intake import initialize_corpus
            value=initialize_corpus(args.plan,args.output);print(json.dumps({'dataset_sha256':value['dataset_sha256'],'tasks':len(value['tasks'])}))
        elif args.command=='annotate':
            from .web import create_annotation_app
            if not 1024<=args.port<=65535:raise ValueError('Choose port 1024–65535')
            url=f'http://127.0.0.1:{args.port}'
            if not args.no_browser:threading.Timer(.8,lambda:webbrowser.open(url)).start()
            print(url,flush=True);create_annotation_app(args.dataset).run(host='127.0.0.1',port=args.port,debug=False,threaded=True)
        elif args.command=='trial':
            from .trial import run_trial
            if args.candidate!='baseline' and not args.weights:
                raise ValueError('Provide the separately installed pinned model using --weights; no weights are downloaded automatically')
            p=run_trial(args.dataset,args.output,args.candidate,args.weights,args.max_tasks)
            print(json.dumps({'prediction_file':str(args.output/'predictions.json'),'chapters':len(p['chapters']),'scope':p['scope'],'production_ready':False}))
        elif args.command=='evaluate':
            from .score import evaluate
            dataset=load_dataset(args.dataset,verify_sources=True)
            gold=json.loads(args.gold.read_text()) if args.gold else AnnotationStore(args.dataset).export()
            result=evaluate(dataset,gold,json.loads(args.pred.read_text()));atomic_json(args.output,result)
            print(json.dumps(result,indent=2))
        elif args.command=='export-labels':atomic_json(args.output,AnnotationStore(args.dataset).export())
        elif args.command=='freeze-labels':AnnotationStore(args.dataset).freeze(args.version,args.output,args.amendment)
        elif args.command=='confirm-exhaustive':AnnotationStore(args.dataset).confirm_exhaustive(args.chapter,args.reviewer,args.human_confirm_entire_chapter_inspected)
        elif args.command=='export-contract':
            from .handoff import export_workspace
            export_workspace(args.workspace,args.output)
    except (ValueError,OSError,RuntimeError) as error:
        parser.exit(1,f'Error: {error}\n')


if __name__=='__main__':main()
