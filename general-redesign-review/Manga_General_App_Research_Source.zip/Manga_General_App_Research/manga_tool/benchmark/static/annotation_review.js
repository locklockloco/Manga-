// Editing a reference never carries an old human check onto new geometry.
function invalidateReference(){if(draft){draft.verified=false;draft.verified_by=null;for(const id of ['native','neighbors','complete','optional'])el(id).checked=false;}}
canvas.addEventListener('pointerdown',()=>{if(el('tool').value!=='pan')invalidateReference();});
for(const id of ['required','ideal','kind','tags','notes'])el(id).addEventListener('change',invalidateReference);
const undoGuard=document.createElement('button');undoGuard.textContent='Undo last detail box';undoGuard.onclick=()=>{if(draft){draft.must_keep_boxes.pop();invalidateReference();fields();}};
const restoreReference=document.createElement('button');restoreReference.textContent='Restore previous revision as draft';restoreReference.onclick=async()=>{try{if(!draft||draft.revision<2)throw Error('No earlier saved revision.');const saved=await api('/api/restore',{id:draft.id,revision:draft.revision-1,expected_revision:draft.revision});labels=labels.filter(a=>a.id!==saved.id);labels.push(saved);draft=saved;updateList();fields();say('Previous reference restored as an unverified draft; history remains intact.');}catch(e){say(e.message);}};
el('export').before(undoGuard,restoreReference);
