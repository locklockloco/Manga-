"""Source-frozen research contracts. These modules cannot approve application crops."""
