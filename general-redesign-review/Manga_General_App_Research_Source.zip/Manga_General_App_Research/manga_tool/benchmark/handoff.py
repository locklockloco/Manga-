"""Portable source/crop contracts and bounded evidence ZIPs, without recompression."""
from __future__ import annotations

import json
import hashlib
import os
from pathlib import Path
import zipfile

from .dataset import atomic_json, file_hash, fingerprint


def export_workspace(workspace, destination):
    from ..pipeline import load_manifest, human_verified, sync_outputs, writing
    root, out = Path(workspace).resolve(), Path(destination).resolve()
    if any(out.is_relative_to(root/p) for p in ['originals','review/revisions','proposals','approved_artwork','needs_review']):
        raise ValueError('Do not write contract metadata into source/revision/artwork folders')
    out.mkdir(parents=True, exist_ok=True)
    with writing(root):
        m = load_manifest(root)
        for source in m['sources']:
            if file_hash(root/source['path']) != source['sha256']:
                raise ValueError('Changed original; no portable handoff is produced')
        sync_outputs(root, m)
        sources = [{'chapter_id':m['chapter'], 'source_id':s['id'], 'order':s['order'],
                    'filename':s['original_name'], 'path':s['path'], 'sha256':s['sha256'],
                    'width':s['width'],'height':s['height'],'chapter_bounds':[0,s['y0'],s['width'],s['y1']],
                    'discontinuity_before':s.get('discontinuity_before',[])} for s in m['sources']]
        lookup = {s['source_id']:s for s in sources}
        crops = []
        for p in m['panels']:
            status = 'APPROVED' if human_verified(p) else 'REJECTED' if p.get('status') == 'REJECTED' else 'UNVERIFIED'
            regions = [dict(r, filename=lookup[r['source_id']]['filename'], sha256=lookup[r['source_id']]['sha256']) for r in p.get('source_regions',[])]
            crops.append({'chapter_id':m['chapter'],'artwork_id':p['id'],'source_regions':regions,
                          'chapter_bounds':p['bounds'],'reading_order_anchor':p.get('reading_order_bounds',p['bounds']),
                          'classification':p.get('classification'),'metadata_only':bool(p.get('metadata_only')),
                          'review_task':bool(p.get('review_task')),'review_status':status,'review':p.get('review',{}),
                          'original_status':p.get('status'),'revision':p.get('revision'),
                          'immutable_revision_file':p.get('file'),'sha256':p.get('sha256'),
                          'projection_file':p.get('output_file'),'parent_id':p.get('parent_id'),
                          'children':p.get('children',[]),'flags':p.get('flags',[]),
                          'narration_beat':p.get('narration_beat'), 'artwork_layers':p.get('artwork_layers')})
        source_manifest = {'schema_version':'1.1','chapter_id':m['chapter'],'sources':sources}
        crop_manifest = {'schema_version':'1.1','chapter_id':m['chapter'],'artworks':crops,
                         'automatic_proposals_are_unverified':True,
                         'history_location':'review/state.sqlite3 plus review/revisions; retain the full workspace for corrections.'}
        atomic_json(out/'sources_manifest.json', source_manifest)
        atomic_json(out/'crop_manifest.json', crop_manifest)
        atomic_json(out/'handoff_manifest.json', {'schema_version':'1.1','chapter_id':m['chapter'],
                    'sources_manifest_sha256':file_hash(out/'sources_manifest.json'),
                    'crop_manifest_sha256':file_hash(out/'crop_manifest.json'),
                    'approved_artwork_count':sum(p['review_status']=='APPROVED' for p in crops),
                    'source_workspaces_are_not_rewritten':True})
    return crop_manifest


def package_files(files, destination, prefix='evidence', max_bytes=4_900_000):
    from ..storage import writer_lock
    out=Path(destination)
    with writer_lock(out):
        return _package_files_locked(files,out,prefix,max_bytes)


def _package_files_locked(files, destination, prefix, max_bytes):
    """Each ZIP is independently extractable; original member bytes are unchanged.

    All parts share relative paths. Oversized members are refused explicitly,
    rather than resized, silently omitted, or put in a deceptively small wrapper.
    """
    if not 100_000 <= max_bytes <= 4_999_999:
        raise ValueError('ZIP budget must be below 5 MB, with room for ZIP metadata')
    if not prefix or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in prefix):
        raise ValueError('Use a simple archive prefix')
    out = Path(destination); out.mkdir(parents=True,exist_ok=True)
    normalized = []
    names = set();expected={}
    for name, source in files:
        path = Path(name)
        if path.is_absolute() or '..' in path.parts or '\\' in name or ':' in name or not name or name in names:
            raise ValueError('Unsafe or duplicate archive member path')
        names.add(name); source = Path(source)
        if source.stat().st_size+2*len(name.encode())+300 >= max_bytes:
            raise ValueError(f'Native file exceeds the ZIP budget; not recompressed or omitted: {name}')
        normalized.append((name,source))
        expected[name]=file_hash(source)
    # Reserve enough for ZIP local/central headers. PNG/JPEG bytes need no codec conversion.
    groups=[];group=[];size=22
    for name,source in normalized:
        cost=source.stat().st_size+2*len(name.encode())+150
        if group and size+cost >= max_bytes:
            groups.append(group);group=[];size=22
        group.append((name,source));size+=cost
    if group:groups.append(group)
    records=[]
    for number,group in enumerate(groups,1):
        path=out/f'{prefix}_{number:02d}.zip';tmp=path.with_suffix('.zip.tmp')
        try:
            with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as archive:
                for name,source in group:archive.write(source,name)
            if tmp.stat().st_size >= max_bytes:
                raise ValueError('ZIP metadata exceeded reserved budget')
            with zipfile.ZipFile(tmp) as archive:
                if archive.testzip() is not None:raise ValueError('ZIP CRC failed')
                for name,source in group:
                    digest=hashlib.sha256()
                    with archive.open(name) as member:
                        for chunk in iter(lambda:member.read(1024*1024),b''):digest.update(chunk)
                    if digest.hexdigest()!=expected[name] or file_hash(source)!=expected[name]:
                        raise ValueError('Source changed during packaging; existing ZIP retained')
            with tmp.open('rb') as handle:os.fsync(handle.fileno())
            tmp.replace(path)
        finally:tmp.unlink(missing_ok=True)
        records.append({'filename':path.name,'bytes':path.stat().st_size,'sha256':file_hash(path),
                        'members':[{'path':name,'sha256':expected[name],'bytes':source.stat().st_size} for name,source in group]})
    atomic_json(out/'package_index.json',{'schema_version':'1.1','max_zip_bytes':max_bytes,'parts':records,
                'instructions':'Extract every ordinary ZIP into one folder, preserving paths. This is research evidence, not a release.'})
    return records
