"""Create a generic benchmark corpus before running a detector, from a chapter plan."""
import json
from pathlib import Path
import re

from ..identity import fingerprint_input
from ..importer import import_chapter
from ..storage import writer_lock
from .dataset import atomic_json,chapter_from_workspace,freeze_dataset,fingerprint,load_dataset


def initialize_corpus(plan_path,destination):
    plan_path=Path(plan_path).resolve();destination=Path(destination).resolve()
    plan=json.loads(plan_path.read_text());jobs=plan.get('chapters',[])
    if not jobs:raise ValueError('Provide chapter records in a corpus plan')
    seen=set();requests=[]
    for job in jobs:
        cid=job.get('chapter_id','')
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,40}',cid) or cid.casefold() in seen:
            raise ValueError('Use unique safe chapter IDs')
        seen.add(cid.casefold());request=dict(job)
        if job.get('available',True):
            if bool(job.get('input'))==bool(job.get('workspace')):raise ValueError('Provide exactly one input or saved workspace per available chapter')
            key='input' if job.get('input') else 'workspace'
            request[key]=str((plan_path.parent/job[key]).expanduser().resolve())
            if key=='input':request['input_identity']=fingerprint_input(request[key],destination.parent/'intake'/cid)
        requests.append(request)
    identity=fingerprint(requests)
    if destination.exists():
        saved=load_dataset(destination,True)
        if saved['provenance'].get('plan_sha256')!=identity:raise ValueError('Frozen plan/input changed; create a new corpus version')
        return saved
    with writer_lock(destination.parent):
        chapters=[];tasks=[]
        for request in requests:
            cid=request['chapter_id'];split=request.get('split','development')
            if not request.get('available',True):
                chapters.append({'chapter_id':cid,'split':split,'available':False,'source_files':[],
                                 'reason':request.get('reason','Not supplied'),'exhaustively_labeled':False})
                continue
            if 'workspace' in request:workspace=Path(request['workspace'])
            else:
                workspace=destination.parent/'intake'/cid
                marker=workspace/'intake_request.json'
                if marker.exists() and json.loads(marker.read_text())!=request:raise ValueError('Changed partial intake; source history retained, use a new corpus folder')
                atomic_json(marker,request)
                imported=import_chapter(request['input'],workspace,include_all=request.get('include_all',False))
                # Do not collapse damaged/missing content into a supposedly complete corpus.
                if imported.get('invalid_sources'):raise ValueError('Damaged/missing source: resolve intake report before freezing this chapter')
                atomic_json(workspace/'reports/manifest.json',{'chapter':cid,'sources':imported['sources'],'panels':[],
                             'excluded':imported.get('excluded',[]),'warnings':imported.get('warnings',[]),
                             'purpose':'BENCHMARK_INTAKE_NO_DETECTOR_RUN','reading_direction':request.get('reading_direction','ltr')})
                if fingerprint_input(request['input'],workspace)!=request['input_identity']:raise ValueError('Input changed during intake')
            chapter=chapter_from_workspace(workspace,cid,split,request.get('style','unspecified'),request.get('acquisition','native_strips'))
            chapters.append(chapter)
            if split=='development':
                sources=chapter['source_files'];count=int(request.get('review_windows',25));span=int(request.get('strips_per_window',3))
                if not(1<=count<=1000 and 1<=span<=12):raise ValueError('Choose 1–1000 review windows and 1–12 strips per window')
                starts=sorted(set(round(i*max(0,len(sources)-span)/max(1,count-1)) for i in range(count)))
                for n,start in enumerate(starts,1):
                    tasks.append({'id':cid+f'_WINDOW_{n:03d}','chapter_id':cid,
                                  'bounds':[0,sources[start]['y0'],chapter['image_width'],sources[min(len(sources)-1,start+span-1)]['y1']],
                                  'sampling':'systematic source windows; no assumed artwork count','verified':False})
        return freeze_dataset(destination,chapters,tasks,{'plan_sha256':identity,'requests':requests,
                     'protocol':'Frozen source hashes, chapter split and source windows before detector inference; no human gold inferred.'})
