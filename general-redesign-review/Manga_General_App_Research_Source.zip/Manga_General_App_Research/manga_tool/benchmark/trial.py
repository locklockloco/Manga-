"""Unchanged geometry versus pinned learned whole-panel detection; no self-approval.

The learned network returns panel/bubble BOXES, not complete drawing masks.
It is a feasibility candidate, never the production detector selected implicitly.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
import time

import cv2
import numpy as np
from PIL import Image

from ..chapter import Chapter
from .dataset import atomic_json, canonical, file_hash, fingerprint, load_dataset, source_regions, valid_box, source_path

MODEL_HASH = '506242d8ce2239cf572f3951dafb433ddf630b3df5ab6389b7dd0d1de474a465'


def task_sources(chapter, bounds, dataset=None):
    selected = [s for s in chapter['source_files'] if max(s['y0'], bounds[1]) < min(s['y1'], bounds[3])]
    if not selected or selected[0]['y0'] != bounds[1] or selected[-1]['y1'] != bounds[3] or bounds[0] != 0 or bounds[2] != chapter['image_width']:
        raise ValueError('Pilot windows must use complete native source strips, not resaved/resized tiles')
    return [dict(s, id=s['source_id'], path=str(source_path(dataset,chapter['chapter_id'],s)) if dataset is not None else s['path'], original_name=s['filename'],
                 y0=s['y0']-bounds[1], y1=s['y1']-bounds[1], mode='RGB') for s in selected]


class PanelBubbleModel:
    """OpenCV ONNX inference with native-coordinate reversal and class-wise NMS."""
    def __init__(self, weights, confidence=.25, nms_iou=.45, cpu=True):
        if file_hash(weights) != MODEL_HASH:
            raise ValueError('Unexpected learned model bytes; use the pinned experiment weights')
        if not (0 < confidence < 1 and 0 < nms_iou < 1):
            raise ValueError('Invalid frozen detection settings')
        if not cpu:
            raise ValueError('GPU candidate has not been evaluated; this experiment supports CPU only')
        self.net = cv2.dnn.readNetFromONNX(str(weights))
        self.net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
        self.net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
        self.confidence, self.nms_iou = confidence, nms_iou

    def detect(self, image):
        rgb = np.asarray(image.convert('RGB'))
        h, w = rgb.shape[:2]
        scale = min(640 / w, 640 / h)
        nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
        dx, dy = (640-nw)//2, (640-nh)//2
        padded = np.full((640, 640, 3), 114, dtype=np.uint8)
        padded[dy:dy+nh, dx:dx+nw] = cv2.resize(rgb, (nw, nh))
        self.net.setInput(np.ascontiguousarray(padded.transpose(2, 0, 1)[None].astype(np.float32)/255))
        rows = self.net.forward()
        if rows.ndim != 3 or rows.shape[:2] != (1, 6):
            raise ValueError(f'Unexpected model output contract: {rows.shape}')
        rows = rows[0].T
        output = []
        for kind in range(2):
            selected = rows[rows[:, 4+kind] >= self.confidence]
            boxes, scores = [], []
            for row in selected:
                cx, cy, ww, hh = map(float, row[:4])
                # Use the actual rounded letterbox scales, not a presumed square source.
                x = max(0, math.floor((cx-ww/2-dx)*w/nw)); xx = min(w, math.ceil((cx+ww/2-dx)*w/nw))
                y = max(0, math.floor((cy-hh/2-dy)*h/nh)); yy = min(h, math.ceil((cy+hh/2-dy)*h/nh))
                if x < xx and y < yy:
                    boxes.append([x, y, xx-x, yy-y]); scores.append(float(row[4+kind]))
            if boxes:
                kept = cv2.dnn.NMSBoxes(boxes, scores, self.confidence, self.nms_iou)
                for index in np.asarray(kept).reshape(-1):
                    x, y, ww, hh = boxes[int(index)]
                    output.append({'bounds': [x, y, x+ww, y+hh], 'kind': 'panel_frame' if kind == 0 else 'dialogue',
                                   'confidence': scores[int(index)], 'drawing_mask_available': False,
                                   'touches_window_edge': x <= 2 or y <= 2 or x+ww >= w-2 or y+hh >= h-2})
        return sorted(output, key=lambda p: (p['bounds'][1], p['bounds'][0], p['kind']))


def run_trial(dataset_path, destination, candidate, weights=None, max_tasks=None):
    if candidate not in {'baseline', 'learned', 'hybrid'}:
        raise ValueError('Choose baseline, learned, or hybrid')
    # Validate identity/source bytes even when all task checkpoints already exist.
    dataset = load_dataset(dataset_path, verify_sources=True)
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=True)
    files = ['composition.py', 'artwork_layers.py', 'detection.py', 'chapter.py']
    package = Path(__file__).resolve().parents[1]
    contract = {'dataset_sha256': dataset['dataset_sha256'], 'candidate': candidate,
                'weights': MODEL_HASH if candidate != 'baseline' else None,
                'confidence': .25, 'nms_iou': .45, 'input_size': 640,
                'baseline_min_gutter': 12, 'baseline_padding': 4, 'baseline_vertical': True,
                'code_sha256': {name: file_hash(package/name) for name in files},
                'adapter_sha256': file_hash(__file__), 'opencv': cv2.__version__,
                'data_contract_sha256': file_hash(Path(__file__).with_name('dataset.py')),
                'scope': 'DEVELOPMENT_WINDOWS_OPERATIONAL_TRIAL_NOT_QUALITY_ACCEPTANCE'}
    identity = fingerprint(contract)
    marker = destination/'experiment.json'
    if marker.exists() and json.loads(marker.read_text()) != {**contract, 'experiment_sha256': identity}:
        raise ValueError('Changed trial input/settings/detector; use a new experiment directory')
    atomic_json(marker, {**contract, 'experiment_sha256': identity})
    model = PanelBubbleModel(weights) if candidate != 'baseline' else None
    chapters = {c['chapter_id']: c for c in dataset['chapters']}
    results = []
    tasks = [t for t in dataset['tasks'] if chapters[t['chapter_id']]['split'] == 'development']
    if max_tasks is not None:
        tasks = tasks[:max_tasks]
    for task in tasks:
        saved = destination/'tasks'/(task['id']+'.json')
        if saved.exists():
            result = json.loads(saved.read_text())
            if result.get('experiment_sha256') != identity or fingerprint(result['payload']) != result.get('payload_sha256'):
                raise ValueError('Corrupt/mismatched completed trial checkpoint')
            results.append(result['payload'])
            continue
        start = time.monotonic()
        chapter = chapters[task['chapter_id']]
        bounds = task['bounds']; sources = task_sources(chapter, bounds, dataset)
        reader = Chapter(destination, sources)
        payload = {'task_id': task['id'], 'chapter_id': chapter['chapter_id'], 'bounds': bounds,
                   'outputs': [], 'source_review_tasks': [], 'layers': [], 'human_approved': False}
        try:
            if candidate == 'baseline':
                from ..detection import propose_compositions
                proposals, _, _ = propose_compositions(destination/'cache'/task['id'], sources, min_gutter=12, padding=4, vertical=True)
            else:
                with reader.render([0, 0, reader.width, reader.height]) as image:
                    detected = model.detect(image)
                payload['layers'] = [dict(p, bounds=[p['bounds'][0], p['bounds'][1]+bounds[1], p['bounds'][2], p['bounds'][3]+bounds[1]]) for p in detected]
                proposals = [{'bounds': p['bounds'], 'confidence': p['confidence'], 'recommended_classification': 'illustration',
                              'ambiguity_flags': ['MODEL_PANEL_FRAME_NOT_VERIFIED_DRAWING_SUPPORT'] + (['INFERENCE_WINDOW_EDGE_COMPOSITION_UNRESOLVED'] if p['touches_window_edge'] else [])}
                             for p in detected if p['kind'] == 'panel_frame']
                if candidate == 'hybrid':
                    from ..artwork_layers import refine_proposals
                    proposals = refine_proposals(reader, proposals)
            for number, proposal in enumerate(proposals, 1):
                x, y, xx, yy = proposal['bounds']; native = [x, y+bounds[1], xx, yy+bounds[1]]
                valid_box(native, chapter['image_width'], chapter['image_height'])
                task_only = proposal.get('metadata_only') or proposal.get('review_task') or proposal.get('proposal_role') == 'child'
                item = {'id': task['id']+f'_{number:03d}', 'bounds': native,
                        'original_candidate_envelope': proposal.get('artwork_layers', {}).get('original_envelope', proposal['bounds']),
                        'envelope_coordinate_space': 'window_local', 'window_offset_y': bounds[1],
                        'kind': 'ambiguous' if task_only else 'artwork', 'status': 'needs_review' if task_only else 'exported',
                        'delivery': 'geometry_prediction_only_no_normal_artwork_PNG', 'human_approved': False,
                        'source_regions': source_regions(chapter, native),
                        'flags': proposal.get('ambiguity_flags', []), 'confidence': proposal.get('confidence'),
                        'artwork_layers': proposal.get('artwork_layers')}
                payload['outputs'].append(item)
            # This is a catch-all source inspection task, not automatic extracted art.
            payload['source_review_tasks'] = [{'id': task['id']+'_SOURCE_REVIEW', 'kind': 'ambiguous',
                'status': 'needs_review', 'bounds': bounds, 'source_regions': source_regions(chapter, bounds),
                'reason': 'All source content remains inspectable; unrecognized art cannot be declared absent.', 'human_approved': False}]
            payload['status'] = 'PROPOSALS_UNVERIFIED'
        except (ValueError, OSError, RuntimeError, cv2.error) as error:
            payload['status'] = 'FAILED'
            payload['error'] = str(error)
            payload['source_review_tasks'] = [{'id': task['id']+'_FAILED', 'kind': 'ambiguous', 'status': 'needs_review',
                'bounds': bounds, 'source_regions': source_regions(chapter, bounds), 'reason': str(error), 'human_approved': False}]
        payload['seconds'] = time.monotonic()-start
        atomic_json(saved, {'experiment_sha256': identity, 'payload_sha256': fingerprint(payload), 'payload': payload})
        results.append(payload)
    prediction = {'schema_version': '1.1', 'dataset_sha256': dataset['dataset_sha256'], 'model_name': candidate,
                  'experiment_sha256': identity, 'scope': contract['scope'], 'chapters': []}
    for chapter in dataset['chapters']:
        if chapter['split'] != 'development':
            continue
        items = [t for t in results if t['chapter_id'] == chapter['chapter_id']]
        prediction['chapters'].append({'chapter_id': chapter['chapter_id'],
             'outputs': [o for t in items for o in t['outputs']],
             'review_tasks': [o for t in items for o in t['source_review_tasks']], 'tasks': items})
    # Window overlap means this trial is not an independent whole-chapter export run.
    prediction['overlapping_windows_are_not_distinct_illustrations'] = True
    atomic_json(destination/'predictions.json', prediction)
    return prediction
