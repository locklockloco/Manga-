"""Versioned human annotation transactions, distinct from application approval."""
from __future__ import annotations

from contextlib import contextmanager
import json
from pathlib import Path
import sqlite3

from ..storage import utc_now
from .dataset import atomic_json, canonical, fingerprint, load_dataset, validate_annotation, source_path


class AnnotationStore:
    def __init__(self, dataset_path, database=None):
        self.dataset_path = Path(dataset_path).resolve()
        self.dataset = load_dataset(self.dataset_path)
        self.path = Path(database) if database else self.dataset_path.parent/'annotations.sqlite3'
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript('''
                CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS annotations(id TEXT PRIMARY KEY, revision INTEGER NOT NULL, payload TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS history(event INTEGER PRIMARY KEY, annotation_id TEXT NOT NULL, revision INTEGER NOT NULL, payload TEXT NOT NULL, saved_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS reviews(chapter_id TEXT PRIMARY KEY, payload TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS freezes(version TEXT PRIMARY KEY, sha256 TEXT NOT NULL, payload TEXT NOT NULL);
            ''')
            row = db.execute('SELECT value FROM metadata WHERE key=?', ('dataset_sha256',)).fetchone()
            if row and row[0] != self.dataset['dataset_sha256']:
                raise ValueError('Annotation database belongs to a different frozen corpus')
            db.execute('INSERT OR IGNORE INTO metadata VALUES(?,?)', ('dataset_sha256', self.dataset['dataset_sha256']))

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        try:
            db.execute('PRAGMA journal_mode=WAL')
            db.execute('PRAGMA synchronous=FULL')
            db.execute('PRAGMA busy_timeout=15000')
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def all(self):
        with self.connect() as db:
            return [json.loads(row[0]) for row in db.execute('SELECT payload FROM annotations ORDER BY id')]

    def save(self, annotation, expected_revision=0):
        chapter = next((c for c in self.dataset['chapters'] if c['chapter_id'] == annotation.get('chapter_id')), None)
        if not chapter or not chapter.get('available'):
            raise ValueError('Unavailable/unknown annotation chapter')
        # Reject changes to originals before committing a source-linked label.
        from .dataset import file_hash
        for source in chapter['source_files']:
            if file_hash(source_path(self.dataset,chapter['chapter_id'],source)) != source['sha256']:
                raise ValueError('Original source changed; annotation is not committed')
        value = validate_annotation(annotation, chapter)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT revision,payload FROM annotations WHERE id=?', (value['id'],)).fetchone()
            revision = row[0] if row else 0
            if revision != expected_revision:
                raise ValueError('Annotation changed in another window; reload before saving')
            if row and json.loads(row[1])['chapter_id'] != value['chapter_id']:
                raise ValueError('Cannot move an annotation ID between chapters')
            value.update(revision=revision+1, saved_at=utc_now())
            if value['verified']:
                value['verified_at'] = value['saved_at']
            # Any edit invalidates chapter-level exhaustive review until reconfirmed.
            db.execute('DELETE FROM reviews WHERE chapter_id=?', (value['chapter_id'],))
            encoded = canonical(value).decode()
            db.execute('INSERT OR REPLACE INTO annotations VALUES(?,?,?)', (value['id'], value['revision'], encoded))
            db.execute('INSERT INTO history(annotation_id,revision,payload,saved_at) VALUES(?,?,?,?)',
                       (value['id'], value['revision'], encoded, value['saved_at']))
        return value

    def restore(self, annotation_id, old_revision, expected_revision):
        with self.connect() as db:
            row = db.execute('SELECT payload FROM history WHERE annotation_id=? AND revision=?', (annotation_id,old_revision)).fetchone()
        if not row:
            raise ValueError('Unknown annotation history revision')
        value = json.loads(row[0])
        # Restoration never silently restores old approval over a new decision.
        value.update(verified=False, verified_by=None, restored_from_revision=old_revision)
        return self.save(value, expected_revision)

    def confirm_exhaustive(self, chapter_id, reviewer, confirm):
        chapter = next((c for c in self.dataset['chapters'] if c['chapter_id'] == chapter_id), None)
        if not chapter or not chapter.get('available') or not reviewer.strip() or confirm is not True:
            raise ValueError('Explicit named human whole-chapter review is required')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            labels = [json.loads(row[0]) for row in db.execute('SELECT payload FROM annotations ORDER BY id')]
            labels = [a for a in labels if a['chapter_id'] == chapter_id]
            if not labels or any(not a['verified'] for a in labels):
                raise ValueError('All chapter annotations must be adjudicated and human-verified first')
            payload = {'reviewer': reviewer, 'reviewer_role': 'human', 'confirmed_at': utc_now(),
                       'annotation_digest': fingerprint(labels), 'statement': 'All artwork and negatives across the entire original chapter were inspected and labeled.'}
            db.execute('INSERT OR REPLACE INTO reviews VALUES(?,?)', (chapter_id,canonical(payload).decode()))
        return payload

    def export(self):
        with self.connect() as db:
            all_labels = [json.loads(row[0]) for row in db.execute('SELECT payload FROM annotations ORDER BY id')]
            reviews = {cid:json.loads(payload) for cid,payload in db.execute('SELECT chapter_id,payload FROM reviews')}
        chapters = []
        for chapter in self.dataset['chapters']:
            labels = [a for a in all_labels if a['chapter_id'] == chapter['chapter_id']]
            review = reviews.get(chapter['chapter_id'])
            chapters.append({**chapter, 'annotations': labels,
                             'exhaustively_labeled': bool(review and review['annotation_digest'] == fingerprint(labels)),
                             'exhaustive_review': review})
        return {'schema_version':'1.1', 'dataset_sha256':self.dataset['dataset_sha256'], 'chapters':chapters,
                'approval_scope':'Benchmark reference labels only; application artwork remains unapproved.'}

    def freeze(self, version, destination, amendment=None):
        if not version or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-' for c in version):
            raise ValueError('Use a stable alphanumeric label version')
        gold = self.export()
        verified = sum(a['verified'] for c in gold['chapters'] for a in c['annotations'])
        if verified == 0:
            raise ValueError('Cannot freeze approved gold with zero human-verified annotations; export drafts instead')
        gold.update(label_version=version, amendment=amendment, frozen_at=utc_now())
        digest = fingerprint(gold)
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            if db.execute('SELECT 1 FROM freezes WHERE version=?', (version,)).fetchone():
                raise ValueError('Label version already frozen; make a new version and written amendment')
            if db.execute('SELECT 1 FROM freezes LIMIT 1').fetchone() and not amendment:
                raise ValueError('A later frozen label version needs a written amendment')
            db.execute('INSERT INTO freezes VALUES(?,?,?)', (version,digest,canonical(gold).decode()))
        # The DB stores the exact snapshot if a crash interrupts the projection.
        atomic_json(destination, {**gold, 'gold_sha256':digest})
        return {**gold, 'gold_sha256':digest}

    def recover_freeze(self, version, destination):
        with self.connect() as db:
            row = db.execute('SELECT sha256,payload FROM freezes WHERE version=?', (version,)).fetchone()
        if not row:
            raise ValueError('Unknown frozen label version')
        gold = json.loads(row[1])
        if fingerprint(gold) != row[0]:
            raise ValueError('Frozen label checksum mismatch')
        atomic_json(destination, {**gold, 'gold_sha256':row[0]})
