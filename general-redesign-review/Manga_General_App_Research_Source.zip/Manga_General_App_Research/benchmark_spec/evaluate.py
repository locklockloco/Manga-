#!/usr/bin/env python3
"""Starter bounding-box scorer for FROZEN HUMAN-VERIFIED manga annotation data.

DO NOT interpret its results as semantic panel correctness or release readiness.
It intentionally refuses scoring chapters with zero verified annotations.
Predicted crops are chapter-global half-open boxes [x0,y0,x1,y1].
"""
import argparse
import json
from pathlib import Path


def box(b):
    if not isinstance(b, list) or len(b) != 4 or any(not isinstance(x, int) or isinstance(x, bool) for x in b):
        raise ValueError(f'Invalid box: {b!r}')
    x,y,xx,yy=b
    if x<0 or y<0 or xx<=x or yy<=y:
        raise ValueError(f'Invalid box range: {b!r}')
    return b


def area(b):
    box(b)
    return (b[2]-b[0])*(b[3]-b[1])


def intersection(a,b):
    box(a);box(b)
    return max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))


def iou(a,b):
    d=area(a)+area(b)-intersection(a,b)
    return intersection(a,b)/d if d else 0.0


def ref_box(a):
    return box(a['bounds'])


def inside_fraction(a,b):
    """Fraction of required reference rectangle a covered by candidate crop b."""
    return intersection(a,b)/area(a)


def evaluate_chapter(gold, predicted):
    chapter=gold['chapter_id']
    verified=[a for a in gold.get('annotations',[]) if a.get('verified') is True]
    if not verified:
        return {'chapter_id':chapter,'status':'INSUFFICIENT_HUMAN_VERIFIED_GOLD','verified_annotations':0,
                'artwork_recall':None,'artwork_precision':None,'message':'No numeric quality score without approved human labels.'}
    artwork=[a for a in verified if a['kind']=='artwork']
    negatives=[a for a in verified if a['kind'] in ('text_only','standalone_sfx','narration_only')]
    outputs=predicted.get('outputs',[])
    exported=[p for p in outputs if p.get('kind')=='artwork' and p.get('status')=='exported']
    review=[p for p in outputs if p.get('status')=='needs_review']
    for item in verified+exported+review:
        box(item['bounds'])
    matches={a['id']:[] for a in artwork}
    crop_matches={p['id']:[] for p in exported}
    for p in exported:
        for a in artwork:
            if inside_fraction(ref_box(a),p['bounds']) >= .90:
                matches[a['id']].append(p)
                crop_matches[p['id']].append(a['id'])
    merges=[p['id'] for p in exported if len(crop_matches[p['id']])>1]
    duplicate_artwork=[a['id'] for a in artwork if len(matches[a['id']])>1]
    pass_ids=[]; clipped=[]; overlarge=[]
    for a in artwork:
        eligible=[]
        for p in matches[a['id']]:
            if len(crop_matches[p['id']]) != 1:
                continue
            protected=a.get('must_keep_boxes') or [a['bounds']]
            protection=min(inside_fraction(box(b),p['bounds']) for b in protected)
            ideal=a.get('ideal_crop_bounds') or a['bounds']
            # An area proxy. It is NOT a semantic pixel-mask whitespace score.
            exterior=max(0,area(p['bounds'])-intersection(p['bounds'],ideal))/area(ideal)
            if protection<.995:
                clipped.append({'artwork_id':a['id'],'crop_id':p['id'],'required_box_coverage':round(protection,5)})
            if exterior>float(a.get('max_excess_area_ratio',.20)):
                overlarge.append({'artwork_id':a['id'],'crop_id':p['id'],'excess_area_ratio':round(exterior,4)})
            if protection>=.995 and exterior<=float(a.get('max_excess_area_ratio',.20)):
                eligible.append(p['id'])
        if len(matches[a['id']])==1 and len(eligible)==1:
            pass_ids.append(a['id'])
    reviewed_artwork=[a['id'] for a in artwork if any(inside_fraction(a['bounds'],p['bounds'])>=.90 for p in review)]
    missed=[a['id'] for a in artwork if not matches[a['id']] and a['id'] not in reviewed_artwork]
    negatives_exported=[]
    for n in negatives:
        for p in exported:
            if inside_fraction(n['bounds'],p['bounds'])>=.80 and not crop_matches[p['id']]:
                negatives_exported.append({'negative_id':n['id'],'crop_id':p['id']})
    exhaustive=gold.get('exhaustively_labeled') is True
    unmatched=[p['id'] for p in exported if not crop_matches[p['id']]]
    correct_exports=set()
    for p in exported:
        if len(crop_matches[p['id']])==1 and crop_matches[p['id']][0] in pass_ids:
            correct_exports.add(p['id'])
    return {
        'chapter_id':chapter,
        'status':'BOX_PROXY_ONLY_NOT_SEMANTIC_VERIFICATION',
        'exhaustively_labeled':exhaustive,
        'verified_artworks':len(artwork),
        'verified_negative_regions':len(negatives),
        'artwork_exports':len(exported),
        'correct_complete_artwork_proxies':len(pass_ids),
        'artwork_recall':round(len(pass_ids)/len(artwork),5) if artwork else None,
        'artwork_precision':round(len(correct_exports)/len(exported),5) if exhaustive and exported else (1.0 if exhaustive and len(exported)==0 and len(artwork)==0 else None),
        'precision_note':'N/A: chapter not exhaustively labeled' if not exhaustive else 'Bounding-box proxy, not semantic mask precision',
        'missed_artworks':missed,
        'routed_to_review':reviewed_artwork,
        'merged_crop_ids':merges,
        'duplicate_artwork_ids':duplicate_artwork,
        'potential_clips':clipped,
        'excessive_rectangle_area':overlarge,
        'false_text_exports_on_verified_negatives':negatives_exported,
        'unmatched_export_ids':unmatched if exhaustive else None,
        'warning':'Proxy based on boxes; a tightly fitted box may still omit objects or include unrelated scenes.'
    }


def evaluate(gold,pred):
    if gold.get('schema_version')!='1.0' or pred.get('schema_version')!='1.0':
        raise ValueError('Expected schema_version 1.0')
    by_id={c['chapter_id']:c for c in pred.get('chapters',[])}
    if len(by_id)!=len(pred.get('chapters',[])):
        raise ValueError('Duplicate chapter ID in predictions')
    results=[]
    for chapter in gold.get('chapters',[]):
        cid=chapter['chapter_id']
        results.append(evaluate_chapter(chapter,by_id.get(cid,{'outputs':[]})))
    return {'scorer_version':'0.1-BOX-PROXY','human_approval_required':True,
            'metric_scope':'Approximate bounding-box overlap on verified reference annotations only',
            'chapters':results}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--gold',type=Path,required=True)
    p.add_argument('--pred',type=Path,required=True)
    p.add_argument('--out',type=Path)
    args=p.parse_args()
    report=evaluate(json.loads(args.gold.read_text()),json.loads(args.pred.read_text()))
    result=json.dumps(report,indent=2)
    if args.out:
        args.out.write_text(result)
    else:
        print(result)

if __name__=='__main__':
    main()
