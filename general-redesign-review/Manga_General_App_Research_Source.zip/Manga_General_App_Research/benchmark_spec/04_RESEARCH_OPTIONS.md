# Research options — study, then measure on our chapter benchmark

## Why classical geometry is insufficient on its own

Color/edge thresholds can find obvious gutters and frame borders. They are unreliable for dark monochromatic scenes, overlapping panel geometry, stylized lettering, speech balloons sharing outlines with figures, painted white skies, compression halos and scene boundaries with no whitespace. Previously observed failures are consistent with these limitations. A trained/promptable model is **worth testing**, but a generic object mask is not necessarily a complete comic scene.

## Candidate A: retain the legacy detector as the baseline

Keep the R7/integrated virtual chapter source mapper, immutable originals, checksums, safe export, checkpoint/resume and review interface. Run its cropping **unchanged** on the frozen dataset to obtain a reproducible baseline. Do not patch examples during evaluation. It may continue to serve as a fall-back for obvious rectangular gutters or in CPU mode.

## Candidate B: whole-composition segmentation / instance grouping model

The key task is to identify **whole illustrated compositions/panels**, not separate characters or the largest colored component. Collect annotated panel-frame masks/boxes and text/background masks. Evaluate a fine-tuned panel instance or semantic-segmentation head (potential choices include Mask2Former-family or YOLO segmentation-family architectures), using overlap-aware grouping and reading order. Train only on material permitted for that use. Choose architecture *after* a pilot; no exact model is selected yet.

## Candidate C: SAM 3 / promptable instance segmentation as a helper

Meta's official SAM 3 can segment open-vocabulary concept instances from text or image exemplars. It may be useful for **annotation assistance**, detecting speech bubbles or foreground components, or candidate masks. **It is not guaranteed to find full manga panels**. A person mask could lead to the unwanted face-only crop. Evaluate whether prompting for illustrated panels/frame regions and then grouping actually outperforms the baseline; report GPU requirements, downloadable weights and license. Official repository: https://github.com/facebookresearch/sam3 and publication: https://ai.meta.com/research/publications/sam-3-segment-anything-with-concepts/.

## Text/OCR is supporting evidence, not the objective

Keep optional OCR or text detection to identify standalone narration/SFX and speech balloons, but distinguish optional exterior dialogue from integral artwork. OCR confidence or rectangular text boxes are not enough to choose a full artwork boundary. Use text-aware segmentation masks when appropriate and make clipping decisions in relation to the *complete* scene's drawing support.

## Annotation tooling

CVAT supports boxes, polygons, and masks; it can export native annotations (https://docs.cvat.ai/docs/dataset_management/formats/format-cvat/). A custom lightweight labeling UI is fine if it exports the same source-referenced coordinates and annotation states. The important constraint is stable human-reviewed labels.

## External comics data and licensing

Manga109 publishes panel/frame and text annotations (https://manga109.github.io/manga109-project-website/en/annotations.html). Its academic Manga109 dataset has non-commercial restrictions and a redistribution prohibition. Its Manga109-s subset has different provisions, including use of certain ML results commercially with conditions. **Read the full license before training, distributing derived assets or republishing panels**, and do not imply that the original Manga109 or the user's uploaded manga is freely redistributable (https://manga109.github.io/manga109-project-website/en/). Traditional page-based manga data may also generalize poorly to vertical scrolling webtoon compositions; use held-out webtoon chapters to test.

## Decision experiment

For each approach collect: labeled artwork recall/precision, merge/split, text-only false export, excess exterior whitespace, cutoff, human correction time, missing scenes, hallucinated/modified pixels, peak RAM/VRAM, inference time, model weight size, CPU fallback and license. Models that trim portraits brilliantly but miss full illustrated action compositions **fail**. Prefer the simplest approach meeting the thresholds on *unseen chapters*. No model has been benchmarked yet under this kit.
