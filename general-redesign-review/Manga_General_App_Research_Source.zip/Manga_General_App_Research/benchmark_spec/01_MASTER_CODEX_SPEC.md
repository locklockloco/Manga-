# MASTER REQUIREMENTS — General-Purpose Manga Artwork Extraction Application

## Mission

**Build a reusable app that can process many different manga/webtoon chapters as a batch and export clean, complete original illustrated compositions for the user's ChatGPT manga recap workflow.** It must not be engineered around one manga chapter, one recurring bubble shape, or ten hand-picked screenshots. Treat the existing R7-era Python codebase as a baseline with useful import, source-mapping, job identity, crash-recovery, immutable revisions and review UI functions, but consider its detector **not validated** for production. You may replace its scene detection, artwork/dialogue segmentation and crop-boundary model when evaluation proves that necessary.

This is a requirements/benchmark-first assignment. **Do not immediately ship another numbered cropper**. Establish a correct test set, a reproducible baseline, and an independently held-out evaluation before major implementation. Existing user chapters are not to be modified; preserve native RGB pixel values in final exports.

## Product-level contract

**Input:** A batch of 1–100+ chapter jobs; each job accepts `.webarchive`, ZIP/CBZ, image folder, or supplied ordered images. Each chapter has a distinct ID and reading direction. Verify sequence and missing/corrupt/duplicate input, dimensions, alignment and file hashes. If the reader saved 690×1280 tiles, a tile is not a panel. A panel can span tiles, and a tile can contain multiple artworks. Do not infer missing pixels, remove duplicates blindly, or join across unknown gaps. Support arbitrary native widths and resolutions.

**Output:** Chapter-scoped `artwork_proposals/`, `approved_artwork/`, `needs_review/`, `excluded_metadata/`, `sources_manifest.json`, `crop_manifest.json`, `comparisons/` and `contact_sheets/`. Default: **all algorithmic proposals are UNVERIFIED**. Only an explicit human action may set APPROVED. `approved_artwork/` must never contain text-only proposals, unknown compounds, silent truncations or unapproved variants. The final handoff ZIP must allow Chapter/Source IDs and original (chapter-global and per-source) pixel regions to be recovered for each crop. Reimport must preserve identifiers, history and approval status.

**Output image shape:** A native-pixel, rectangular crop with **its original aspect ratio**. Do not force 16:9. If useful, a transparent art mask may be provided *separately as an optional layer* after verification; do not conflate it with the intact source crop. No painting, redrawing, deletion of pixels inside the retained rectangle, hallucination or background reconstruction.

**User-facing goal:** A person can upload multiple chapters, start a batch, review the small fraction of difficult outputs and download one package ready to align with narration. The app should operate outside ChatGPT as a CLI/local UI first; the output ZIP should be usable in ChatGPT. A live ChatGPT app/connector or hosted endpoint would require a separately deployed integration and is a later stage, not something the local `start.py` grants automatically.

## Non-negotiable drawing policy

1. Complete illustrated compositions come first. Preserve faces **and** bodies, limbs, weapons, boats, monsters, environments, foreground/background details and action cues. A crop is not a character-object detector and should not automatically tighten to a face.
2. Text-only narration, standalone SFX and isolated words are not ordinary artwork exports. Keep their position and source metadata for reversible review, without generating a redundant standalone PNG for each word.
3. Speech/dialogue balloons are **optional** when choosing a drawing rectangle. Do not expand a crop merely to retain them. It is acceptable for a balloon to be cut if doing so keeps the complete drawing.
4. Where a speech balloon **overlays artwork inside the rectangle**, its appearance remains: a crop cannot reveal content that was never drawn. Do not call this an algorithmic failure if the only way to remove it would delete drawn material. Flag it as `embedded_balloon_geometry_limit`.
5. Remove exterior gutters and large dialogue-only bands when they are separable from drawn content. Do not remove intentionally blank skies, snow, walls, white clothing, bright backgrounds or dark atmosphere just because they have low texture.
6. Source strips are arbitrary technical boundaries. Rebuild compositions across seams, then separate actual drawings. A long continuous picture may legitimately remain very tall; giant **multi-scene** regions are not valid artwork. Use content evidence, not size alone, to decide.
7. Do not decide reading order from newly cropped top-left edges when a speech balloon was removed; retain original scene anchors and handle side-by-side panels in the appropriate reading direction.
8. Unknown ink must not be silently discarded. If its identity cannot be established, send it to a clearly labeled review queue with original source context.

## Why existing approaches underperform

The V3.x/R7 tools improved some dark-scene grouping and white-header trimming but are still dominated by hand-tuned geometry/color thresholds and text/OCR hints. Their quality checks were often **pixel exactness of exported rectangles**, which does not prove a drawing was fully included or independently separated. Previous release reports gave many unapproved proposals and persistent merged scenes. Fixing `CH05_P100` or `CH05_P108` alone does not establish general performance. A new candidate must be judged without changing the ground truth between runs.

## Architecture to build and compare

### Stage A: immutable intake and chapter coordinate map

- Extract originals safely. Prevent archive traversal, decompress bombs, unbounded file count/size and cross-chapter name collisions.
- Compute SHA-256 hashes for each original. Record exact page/strip order, dimensions, source-to-chapter row transforms, discontinuities and chapter ID.
- Join sequential same-width strips **logically** into a continuous virtual coordinate space; do not allocate a multi-gigapixel raster to RAM. A stitch may preserve original pixels with no blending; if overlap/gaps suspected, report explicitly.
- Keep all source bytes unchanged and verify no source lost; make the process crash-safe and resumable.

### Stage B: panel/composition discovery (not final cropping)

- Detect separate whole illustration instances, including 2+ drawings within one strip, 1 illustration across N strips, dark/colored gutters, diagonal frames, embedded speech, irregular borders, overlapping panels and open-background webtoon paintings.
- Evaluate at least two genuinely different approaches: (1) legacy R7 composition/geometry baseline; (2) learned scene/panel segmentation or a promptable segmentation candidate with a panel-level grouping model. An ensemble may be evaluated, but avoid implementing an unmeasured zoo of heuristics.
- If a general object-segmentation model is used, **prove it groups objects into one complete scene**. Individual person/face masks are not complete panel masks. Use scene instances, frame geometry and source continuity.
- For ambiguous boundaries, output two alternatives as **one review task** with neighboring context, never an explosion of word-sized crops or silently combined panels.

### Stage C: independent dialogue / text / drawing layers

- Estimate illustrated scene support, speech/dialogue including outside balloons, standalone narration/SFX, intentional background and uncertain ink as distinct entities. Text OCR alone is not an artwork model. A bubble's sharp border must not outweigh an entire drawing.
- Only remove an optional text band when it is separable from essential illustrated support. Preserve native pixels inside the selected crop. A speech balloon already inside a scene is allowed and is not a reason to crop into a character.
- For each candidate, retain an **original candidate envelope**, a **final proposed crop**, a drawing-support mask, optional-dialogue mask, unknown/occlusion masks, confidence and source coordinates. Do not treat noisy predicted masks as true labels.
- If a rectangular frame cannot omit a bubble without cutting art, keep the complete drawing and mark a geometry limitation rather than inventing transparency/pixels.

### Stage D: error prevention and confidence / abstention

- Detect possible merged scenes, incomplete composition, cutoff risk, excessive external white/text area, duplicate/near-duplicate crops, source gaps, uncertain order, text-only output and inconsistent joins.
- `high confidence` is an evidence field, **not** automatic user approval. Before auto-export to the general proposal gallery, preserve uncertain content in source review; approved exports require a review decision unless the user explicitly opts into a separately validated auto-accept setting.
- Surface the **cause** of review and a side-by-side original-neighbor view. Support one-click ignore text, split, merge, adjust boundaries, restore source region, undo and bulk review with per-item transaction integrity.

### Stage E: multi-chapter batch and ChatGPT handoff

- Support queue of many chapter archives with deterministic IDs; parallel workers with bounded CPU/GPU/RAM/disk, per-chapter failure isolation, progress and checkpoints. Resume after process exit without mixing jobs or clobbering corrections.
- Atomic file writes, SHA-256 output checks, corrupted-export repair from immutable revisions and strict workspace-input identity; avoid accidentally returning crops from a previous chapter.
- Export a package manifest listing chapter ID, artwork ID, source filenames and byte hashes, coordinates, group membership, labels/flags, status and linked narration beat if supplied. Version the schema and support reimports.
- Provide a `--cpu` mode even if slower, plus a GPU mode if a learned model passes evaluation. Document exact model/license/weight downloads and CPU/GPU requirements; do not download model weights without informing the user of size/licensing.

## Dataset and anti-overfitting protocol

**Before training or tweaking thresholds**, freeze: source hashes, a labeling guide, annotations, train/validation/test chapter assignment, test scripts, baseline outputs and a unique run ID. Version the labels; changing a frozen label requires a written amendment and a new test version.

Minimum prototype: 30–50 carefully labeled diverse illustrations over multiple chapter segments, with separate text-only and failure cases. This is enough to debug evaluation mechanics, **NOT** enough to claim generalization. Expand toward **at least 200 reviewed illustrations across multiple complete chapters**, including a different series or style. Record uncertainty when a crop is inherently ambiguous. Source IDs, exact box/mask coordinates and human review status are mandatory.

Separate **development chapters** from **unseen holdout chapters**. Never tune on held-out labels or contact sheets. Our current Chapter 1 and Chapter 5 problem cases are *development* cases because we have repeatedly adjusted algorithms around them. Chapters 2–4 can serve as provisional holdouts only if kept untouched until evaluation; their currently available archives are preassembled continuous sources, so they test scene extraction more directly than raw-tile reconstruction. For the final cross-style holdout, obtain independently supplied material with appropriate usage rights. Avoid publishing copyrighted chapter artwork as public training collateral without permission.

Use the same frozen images, annotation rules and budget for all candidate models. Choose by **unseen-chapter image quality**, not by an easy Chapter 1 score or raw model IoU on people.

## Required deliverables in order

1. **Source inventory / frozen split** (what images are development, validation and untouched test; source hashes) and annotation plan. No model tuning yet.
2. **Baseline evaluation report** showing all unverified cases as such and quantitative metrics only for fully reviewed labels.
3. **Model feasibility trial:** sample a few dozen representative, appropriately labeled illustrations; compare legacy geometry, a learned candidate and a hybrid using exact same test. Report memory, runtime, external dependencies, failure examples and license.
4. **Implementation:** one integrated working application with audited importer, detector, output/export, review UI and batch queue.
5. **Independent holdout scorecard:** precision, recall, clipped-art cases, merged/split, excess blank/exterior-dialogue, missed artwork, text-only false exports, time/VRAM, crash recovery; stratify by manga and panel type.
6. **Evidence:** readable full-scene side-by-sides with source ID and overlay crop rectangle, all failures, not just selected successes. Make raw predictions available to reproduce metrics.
7. **Release candidate only when accepted**. All other builds are experiments. Preserve old app/code until accepted.

Do not call work complete based on a numeric version, passed unit tests, exported count or pixel fidelity alone. State exactly what was human-inspected and what remains untested.

## Contract for this first Codex session

Do not begin by replacing the whole application. Implement the **dataset/annotation/export contract + evaluator integration + baseline benchmark + model feasibility study** first, with a concrete architecture decision and initial visual results. Only proceed to rewriting/finetuning a detector if the benchmark supports it. The aim is one reliable general-purpose system rather than more ad hoc per-panel patches.
