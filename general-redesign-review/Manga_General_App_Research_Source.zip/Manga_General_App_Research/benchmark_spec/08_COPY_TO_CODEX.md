# Message to send to Codex (copy verbatim)

I want to stop creating new manga cropper versions that fix only one or two pictures. We are building a **general-purpose, multi-chapter manga artwork extraction application for my ChatGPT manga recap workflow**, not a Leviathan-only Chapter 1 or Chapter 5 cropping script.

I've attached `MANGA_GENERAL_APP_REDESIGN_KIT.zip`.

1. Read `START_HERE.md` and `01_MASTER_CODEX_SPEC.md` completely, plus the labeling guide and evaluation gates. Treat these as the development contract.
2. Inspect the existing app and keep its safe importer, source mapping, file-integrity checks, crash recovery and review interface wherever possible. The current artwork detector is NOT accepted as production-ready; you may replace it.
3. **Do not immediately add another heuristic patch or announce a release.** First build/freeze a human-reviewable reference dataset and evaluation tool, benchmark the current system, and test at least one genuinely different artwork/panel segmentation approach. The program must understand complete drawn scenes, NOT merely segment faces or speech bubbles.
4. The program must reconnect illustrations across source strips, split multiple artworks within one strip, remove outside gutters/dialogue-only bands, ignore isolated words/SFX, and preserve every important illustrated character, weapon, monster, prop and background. Speech bubbles can be clipped; important drawing cannot. Preserve original pixels and native proportions.
5. Design for **many different chapters in a single batch**. The app must support ChatGPT-friendly ZIP outputs with exact chapter/source mapping, as well as restart/recovery and bounded memory.
6. Freeze the development/holdout split before tuning. Chapter 1 and Chapter 5 are already development examples. Test on other unmodified chapters and eventually a different manga style. No claim of high precision or recall unless evaluated against sufficient **approved**, exhaustive human annotations. Keep uncertain crops in review; don't automatically mark anything VERIFIED.
7. Deliver the source inventory, annotation protocol/UI, baseline scorecard, one learned/model-assisted feasibility trial, implementation plan based on evidence, representative real before/after tests, and a statement of what remains unverified. Implement substantive improvements after the approach has been measured.

Do not hardcode CH05_P100, CH05_P108 or other known bad IDs as special rules. Do not call this done because tests pass, it exports more PNGs, or the examples we already complained about look better. Show evidence that the approach works on chapters it wasn't optimized for. One proven engineering upgrade, not 20 tiny versions.
