import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from evaluate import evaluate, iou


def scaffold(annotations,outputs,exhaustive=True):
    gold={'schema_version':'1.0','chapters':[{'chapter_id':'T1','exhaustively_labeled':exhaustive,'annotations':annotations}]}
    pred={'schema_version':'1.0','chapters':[{'chapter_id':'T1','outputs':outputs}]}
    return evaluate(gold,pred)['chapters'][0]


def art(id,rect):
    return {'id':id,'kind':'artwork','bounds':rect,'ideal_crop_bounds':rect,'verified':True}


def crop(id,rect,status='exported'):
    return {'id':id,'kind':'artwork','bounds':rect,'status':status}


def test_no_verified_reference_reports_no_score():
    r=scaffold([{'id':'A1','kind':'artwork','bounds':[0,0,100,100],'verified':False}], [crop('P1',[0,0,100,100])])
    assert r['status']=='INSUFFICIENT_HUMAN_VERIFIED_GOLD'
    assert r['artwork_precision'] is None


def test_perfect_synthetic_annotations_match():
    r=scaffold([art('A1',[0,0,100,100]),art('A2',[0,120,100,220])],
               [crop('P1',[0,0,100,100]),crop('P2',[0,120,100,220])])
    assert r['artwork_recall']==1.0 and r['artwork_precision']==1.0
    assert not r['merged_crop_ids']


def test_compound_scene_is_not_credited_twice():
    r=scaffold([art('A1',[0,0,100,100]),art('A2',[0,120,100,220])],
               [crop('P1',[0,0,100,220])])
    assert r['artwork_recall']==0 and r['merged_crop_ids']==['P1']


def test_text_only_export_is_false_artwork():
    r=scaffold([{'id':'SFX1','kind':'standalone_sfx','bounds':[0,0,100,100],'verified':True}],
               [crop('P1',[0,0,100,100])])
    assert len(r['false_text_exports_on_verified_negatives'])==1


def test_partial_gold_cannot_claim_precision():
    r=scaffold([art('A1',[0,0,100,100])],[crop('P1',[0,0,100,100])],exhaustive=False)
    assert r['artwork_recall']==1 and r['artwork_precision'] is None


def test_review_is_not_automatic_success():
    r=scaffold([art('A1',[0,0,100,100])],[crop('P1',[0,0,100,100],status='needs_review')])
    assert r['artwork_recall']==0 and r['routed_to_review']==['A1']


def test_detects_required_content_clipping():
    r=scaffold([art('A1',[0,0,100,100])],[crop('P1',[5,0,100,100])])
    assert r['artwork_recall']==0 and len(r['potential_clips'])==1


def test_excess_area_is_not_good_crop():
    r=scaffold([art('A1',[0,0,100,100])],[crop('P1',[0,0,100,160])])
    assert r['artwork_recall']==0 and len(r['excessive_rectangle_area'])==1


def test_iou():
    assert iou([0,0,10,10],[0,0,10,10])==1.0


def test_shifted_crop_same_area_is_not_considered_clean():
    # Same size but shifted into unneeded blank canvas.
    r=scaffold([art('A1',[0,0,100,100])],[crop('P1',[10,0,110,100])])
    assert r['artwork_recall']==0
    assert len(r['potential_clips'])==1
