# Evaluation, errors and release gates

## Ground-truth first: do not invent an accuracy score

No current app version has a complete, independently verified ground-truth set across these chapters. Full Chapter 1 or Chapter 5 runs with zero source hash errors are **not** evidence that 100% of useful illustrated scenes were extracted. The 194/85 source counts, reported candidates, hand-inspected examples and synthetic tests are separate kinds of evidence. Use only approved, frozen labels for numeric panel-quality performance.

### Split the corpus by **chapter**, not random crop

- **Development:** Chapter 1 and Chapter 5 known cases (already repeatedly used to tune the detector). They can catch regressions but are not unbiased generalization proof.
- **Holdout A:** whole Chapters 2–4 as future unseen chapter-level tests. Existing continuous-source archives are useful for artwork segmentation, but may not be raw original tiles; document acquisition and source-hash equivalence before using them to score joining.
- **Holdout B:** at least one independently supplied different manga/webtoon style, with license/usage permission and no tuning based on its labels.
- **Stress:** synthetic multi-chapter combinations and genuine source batches, including 10+ chapters; this tests throughput and recovery, not semantic artwork quality.

A chapter must be labeled *exhaustively* before computing export precision or false positive counts. Partially labeled chapters can still measure recall **on known labeled instances** but cannot prove no false exports in unlabeled locations.

## Annotation targets

For each *artwork instance*, save: `artwork_id`, chapter ID, source strip IDs and hashes, `required_artwork_mask` or minimum complete-artwork bounds, `ideal_crop_bounds`, optional geometry exceptions, reading order, flags and human approval. Include negative `text_only` and `standalone_sfx` instances. Distinguish **embedded balloon** from **exterior balloon** and **intentional blank background** from unwanted outside paper.

## Error taxonomy (count each separately)

- **MISS:** important artwork not represented by any crop or review task; silent loss is critical.
- **CUT:** an output rectangle excludes required drawn content (not just dialogue); critical.
- **MERGE:** unrelated illustrated scenes combined as one artwork proposal; serious.
- **SPLIT:** one complete illustration cut into several unrelated exports, no complete composition available; serious.
- **DUPLICATE:** multiple redundant exports of same illustration, excluding explicitly intentional approved variants.
- **WHITESPACE/DIALOGUE BAND:** separable outside paper or dialogue takes excessive crop area; moderate/serious depending on magnitude.
- **FALSE ART:** standalone text/SFX/narration exported as normal artwork.
- **SEAM:** a technical strip split incorrectly becomes a panel boundary or two unrelated sources are stitched.
- **READ ORDER:** crop sequence differs from actual reading order.
- **SOURCE INTEGRITY:** any original pixels changed, missing/corrupted file, stale-chapter reuse or altered source hash; critical.
- **UNSAFE CONFIDENCE:** uncertain/unapproved output falsely labeled finished; critical.
- **REVIEW OVERLOAD:** too many uncertain drafts or non-art fragments to review; operational failure.

## Primary metrics (per chapter AND aggregate, with confidence intervals on holdout)

1. **Illustration recall:** fraction of human-labeled illustrated compositions represented by **one correct complete** export. Track separately the fraction safely referred to review. Review routing ≠ successful automatic extraction.
2. **Artwork export precision:** fraction of artwork exports matching exactly one approved artwork and passing artwork-completeness/whitespace checks. Meaningful only if all artwork/negatives within the evaluation chapter are labeled.
3. **Required-drawing retention:** pixel/mask coverage of annotation's essential artwork, or minimum bounding rectangle containment where masks unavailable. Use native coordinates.
4. **Excess exterior ratio:** `(exported rectangle area outside the acceptable ideal rectangle) / ideal rectangle area`, excluding legitimately intended background and embedded balloons. This is only a geometry proxy—inspect actual composition.
5. **Merge/split/duplicate rates** against individual artwork instance IDs.
6. **Text-only false exports** among verified standalone negatives.
7. **Silent loss rate** and **review fraction**; state the fraction of all distinct art instances requiring human correction.
8. **Reliability:** number of chapters processed, source hashes, corrupt files detected/repaired, stale reuse prevented, recovery with source IDs preserved, peak RSS/VRAM/disk and runtime per 100 source strips.

## Proposed release gates — *targets*, not achieved results

- **100%** original source SHA-256 matches and recoverable source-to-output mappings; zero wrong-chapter reuse.
- **Zero observed critical CUT/MISS/MERGE/SEAM/UNSAFE CONFIDENCE failures in a fully inspected, held-out release acceptance batch.** If one occurs, don't release unattended mode; use supervised review.
- Target **≥98% complete-scene recall** and **≥98% accurate export precision** on exhaustively human-labeled unseen chapters; publish numerator/denominator and per-style scores. These values are proposed go/no-go thresholds, not a promise or statistical proof of zero future mistakes.
- Target **≥99.5% required artwork-mask retention** on labeled complete output masks. Bbox-only proxy is insufficient to establish that small important details were preserved.
- **Zero standalone text/SFX artwork exports** among held-out verified negative examples.
- `approved_artwork/`: **0** unapproved proposals, with explicit audit trail. The algorithm must not silently approve itself.
- **10+ chapter stress job** with deterministic output order, no lost edits/duplicated IDs on crash/resume, no source swaps and bounded memory; include corrupted input and interrupted export.
- Acceptance on a **different, held-out series/style** before claiming broad generalization.
- Publish how many cases were routed to review, how much time review took, and whether the auto-ready fraction is high enough to be useful. A pipeline that sends everything to review has not achieved the user's automation goal.

No fake denominator. If a test is not exhaustively labeled, mark whole-chapter precision `N/A`. If only a dozen positives are labeled, do not write “99% success”. A model that abstains safely can be useful but should not be advertised as automatic successful extraction.

## Experiment protocol for Codex

1. Generate a source manifest with native byte checksums, IDs and logical chapter coordinates.
2. Freeze ~30–50 representative labels to validate annotation definitions and evaluate one baseline and one learned alternative; include dark/white scenes and real failure cases.
3. Add more labels to ≥200 illustrations across development and held-out chapters. Different artistic styles matter more than random crops from the same sequence.
4. Run current R7 or integrated composition detector unchanged: save proposals and metrics.
5. Evaluate 1–2 candidate whole-panel/scene models (optionally segmentation masks + OCR + geometry grouping) with the same image set and fixed review budget.
6. Do not silently tune on holdout. When development is satisfactory, freeze parameters and evaluate holdout once; if holdout fails, declare that test set used and collect a new, untouched holdout for future claims.
7. Fix only underlying failure categories with new regression tests; no per-panel IDs hardcoded.
8. Keep all failures and selected successes visible, with native source crop + proposed rectangle + reference annotation overlay.
9. Run 10+ chapter batch stress after accuracy is demonstrated, not in place of it.
10. Release an *approved* build only after testing and human signoff. Preserve old working application as rollback.

## Starter scorer limitations

`evaluate.py` included in this kit is a small reproducible **bounding-box** sanity evaluator. It reports matching, clipping and merging proxy metrics for *verified* annotations, and marks precision `N/A` on partially annotated chapters. It does **not** compute segmentation mask IoU, human composition quality, source integrity or statistical confidence intervals. Codex must implement these before accepting a general-purpose release.
