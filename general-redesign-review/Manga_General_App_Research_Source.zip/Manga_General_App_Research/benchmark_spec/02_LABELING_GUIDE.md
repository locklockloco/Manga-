# Visual labeling guide — Complete artwork, not speech bubbles

## Purpose

Create reference annotations with explicit source IDs and coordinates to compare candidate apps fairly. **No source-verified ground truth has been approved yet**. A tool's proposed crop, an assistant's visual guess, or a previously generated positive example is not a verified gold annotation.

## Coordinate system

Use the chapter's logical, native-pixel coordinate space. Every box `[x0, y0, x1, y1]` is half-open (x1/y1 exclusive) and refers to a rectangle in the original virtual page made by sequentially stacking valid native strips. Convert back to individual native source strips in the source map; store original filenames and SHA-256. Never label based on rescaled contact-sheet pixels. Preserve reading direction, source ID, and image discontinuities.

## Annotate each complete illustration

- `kind = artwork`: one *complete illustrated composition/scene* (not each person or speech bubble). Draw `required_bounds` or, ideally, a polygon/mask covering what must remain; also record `ideal_crop_bounds`, the tight rectangular box preserving the **whole illustrated scene** without unnecessary exterior whitespace. Mark intended background as part of the illustration.
- `kind = text_only`: standalone narration blocks, disconnected speech/SFX with no meaningful artwork; preserve source coordinates but do not export as artwork.
- `kind = ambiguous`: overlapping/composite art, connected gutters, internal white space, or semantically unclear fragments. This requires human review; do not train a hard positive/negative from it without adjudication.

`verified = true` only after a person has inspected the original at native size, confirmed all expected illustrated objects/setting, checked adjacent artwork and committed the annotation. An annotator should record their name/role, date, schema version and notes. Assistant-generated candidate labels stay `verified = false` until accepted.

## Full composition rule

**Keep:** complete characters, body/limbs, boats/monsters/weapons/props, full backgrounds including water/snow/sky/darkness, illustrated effects required for the action, complete panels whose painted boundaries span multiple technical strips.

**Can cut if outside drawing:** speech bubbles, words, isolated captions, gutter, external white paper and decorative page margin. **Cannot safely remove by rectangle:** a balloon that actually overlays a character/background inside the painted scene; keep the original pixels and flag it. Do not crop inside an essential drawing to hide embedded dialogue. Do not produce a zoomed face as substitute for a wider full scene.

**One-to-many and many-to-one:** One 690×1280 strip may contain multiple separately labeled artworks; a continuous drawing crossing S0039–S0040 should get **one artwork ID** with multiple source regions. One image can legitimately contain staggered/overlapping subpanels—when source intent is not clear, annotate group/child relationships explicitly.

**Optional separate labels:** `dialogue`, `sfx`, `narration`, `exterior_paper`, `intentional_blank`, `uncertain_ink`. Use polygons when possible. These contextual layers guide trimming but they are not independent artwork instances.

## Minimum QA for every gold crop

1. Open original and at least one neighboring source strip above/below.
2. Check no character, limb, object, environment or significant context is cropped out.
3. Check the desired rectangle doesn't include a large separable dialogue-only band or unrelated second scene.
4. Confirm source seam alignment and order.
5. Record source ID(s), required/ideal bounds, label type and difficult-case tags.
6. Mark as human verified only after inspection. A model cannot approve itself.

## Difficult case tags to cover in benchmark

`dark_art`, `white_art`, `multiple_in_strip`, `cross_strip`, `irregular_border`, `overlapping_panels`, `colored_gutter`, `diagonal_frame`, `floating_balloon`, `embedded_balloon`, `standalone_sfx`, `text_only`, `intentional_blank`, `large_background`, `monochrome`, `compound_scene`, `low_resolution`, `compression_halo`, `narration_only`, `long_vertical_art`.

## Recommended annotation UI

A local review interface with pan/zoom to native pixels, split/merge, polygons for artwork/text/background/uncertain, one-click scene ID assignment and exact source-coordinate export. CVAT supports polygons, boxes and masks and can export annotations; any other tool is fine if it faithfully exports this schema. Store annotations privately or in a repository without copyrighted originals unless redistribution rights are established.
