# Manga Artwork Extractor — General-Purpose Redesign Kit

**Status: specification + evaluation foundation, NOT a new cropping app and NOT a release.**

## The product we are building

A reusable, multi-chapter artwork extractor for the user's ChatGPT manga recap workflow. A chapter may consist of fixed-height WEBTOON image strips, a ZIP, a Safari WebArchive, or an ordered image folder. The system must rebuild sequential source content, find separate **complete illustrations**, and export the natural-size original artwork without white gutters or dialogue-only margins. Speech bubbles may be cut when optional; illustrated backgrounds and other drawing content may not be sacrificed for cleaner framing. Uncertain results must not masquerade as verified panels.

This is NOT a one-chapter Leviathan patch. Its success must be established on held-out chapters and another art style, not on the same panels used to tune it.

## Included files

1. `01_MASTER_CODEX_SPEC.md` — implementation mandate, architecture, test and release obligations.
2. `02_LABELING_GUIDE.md` — what counts as a full illustration; annotation categories, coordinate conventions and difficult cases.
3. `03_EVALUATION_AND_RELEASE_GATES.md` — error taxonomy, metrics, dataset splits, safe abstention, performance and test plan.
4. `04_RESEARCH_OPTIONS.md` — model candidates and their limits; sources, licensing caveats and decision experiment.
5. `05_KNOWN_FAILURES.json` — real source-linked failures, **NOT APPROVED GOLD LABELS**.
6. `06_GOLD_TEMPLATE.json` and `07_PREDICTION_TEMPLATE.json` — empty templates; no invented coordinates or user approvals.
7. `evaluate.py` and `tests/test_evaluate.py` — small proof-of-concept quality evaluator with synthetic tests. It refuses to produce a success score without human-verified annotations. This is a starter, not a complete semantic evaluator.
8. `08_COPY_TO_CODEX.md` — short message for Codex pointing to the full mandate.

## Start in this order

- Read `01_MASTER_CODEX_SPEC.md`, then `02_LABELING_GUIDE.md` and `03_EVALUATION_AND_RELEASE_GATES.md`.
- **Freeze a test set before tuning.** Current real assets: CH01 original WEBTOON strips and CH05 original/continuously recovered strips; CH02–CH04 continuous-source archives are available but must be treated as preassembled files unless raw native strips can be retrieved and verified. The current R7 ZIP is a reusable baseline, not an accepted detector.
- Produce **manual reference labels** (first 30–50 representative illustrations, later >=200 across multiple chapters/styles) using a consistent annotation interface. The user's explicit thumbs-up for the fork crop can be a qualitative positive, but unless an exact gold boundary was reviewed it is not a verified numeric label.
- Benchmark the current detector and at least one genuinely different candidate (panel/illustration segmentation model) on the **same** frozen images and definitions.
- Build only the winner or a combined cascade, then test on unseen chapters.
- Deliver an application and ChatGPT-compatible ZIP handoff with exact chapter source IDs, not unsupported claims that a local script is a permanently installed ChatGPT feature.

## What counts as progress

A reliable measured decrease in bad crops on *held-out images*, with zero silent image loss and no unreviewed crop labeled VERIFIED. More PNGs, shorter processing time, tighter individual samples and green unit tests do not by themselves establish image quality.

### Evidence status

`05_KNOWN_FAILURES.json` lists previously inspected source locations and problems. The labels are **candidate issues**, not verified annotation truth. No independent full-chapter panel accuracy number has been established in this kit.
